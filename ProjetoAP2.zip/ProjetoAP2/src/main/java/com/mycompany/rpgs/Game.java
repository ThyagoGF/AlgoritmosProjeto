package com.mycompany.rpgs;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

//import com.mycompany.rpgs.aranhaGigante;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author rodrigo
 */

public class Game {
    
    static Scanner ent = new Scanner (System.in);
    
    // inimigos
    static Player jogador;
    static Inimigo inimigoMortoVivo;
    static Inimigo inimigoAranhaGG;
    static Inimigo inimigoArcnae;
    static Inimigo inimigoLadrao;
    static Inimigo inimigoMinota;
    static Inimigo  inimigoDrg;
       
    static boolean estaRodando;
    
    static int local = 0, passagem = 1;
    static String[] locais = {"Castelo","Dentro da Floresta", "Floresta", "para o sul"};
    
  
    
     // inia entrada do usuario 
   static int usuarioEntra(String chamar, int userUsuario){
       int input = 0;
       do{
           System.out.println(chamar);
           try{
               input = Integer.parseInt(ent.next());
           }catch(Exception e){
               input = -1; 
               System.out.println(" informe um numero");
           }
       }while(input < 1 || input > userUsuario);
       return input;
   }
   
   //*************** Tela********************
    
   // metodo para simular a limpeza do console
   static void limpaTudo(){
       for(int i = 0; i < 10;i++){
         System.out.println();
       }
   }
   // metodo usado para imprimir um separador em comprimento
   static void telaDesenha(int n){
       for(int i = 0; i < n; i++){
           System.out.println("----------");
           System.out.println();
       }
   }
   
   static void apareceTela(String title){
      telaDesenha(1);
       System.out.println(title);
      telaDesenha(1);
           }

   // metodo para parar o jogo ate que o usuario digite qualquer coisa
    static void digitaAlgo(){
        System.out.println(" digite qualquer  coisa para continuar");
        ent.next();
    }
    
    // ************** Inicia *****************
    
  // metodo para iniciar o jogo 
   static void iniciaJogo() throws Exception{ 
       boolean nomeQual = false;
       String nome;
       // imprime o title
       limpaTudo();
       telaDesenha(1);
       System.out.println(" nome do Jogo");
       System.out.println(" subtitilo");
       telaDesenha(1);
       digitaAlgo();
       
       // pega o nome do Jogador
       do{
           limpaTudo();
           apareceTela(" Como voce se chama ?");
           nome = ent.next();
           // ira perguntar se o nome do player esta correto
           limpaTudo();
           apareceTela(" O seu nome é " + nome + " mesmo ?");
           System.out.println("(1) sim");
           System.out.println("(2) não meu nome é"); 
           int input = usuarioEntra( "@> ", 2);
           if(input == 1)
               nomeQual = true;
       }while(!nomeQual);
       
      // cria o player com nome
       jogador = new Player(nome);
       escolheRaça();
 
   }
   
  
static void escolheRaça() throws Exception{
     limpaTudo();
  
           apareceTela(" Você está iniciando a sua jornada. Escolha uma Raça: ");
       
        System.out.println("(1) Anão." );
        System.out.println("(2) Elfo." );
        System.out.println("(3) Tiefling.");
        // Obter a escolha do jogador
        int input = usuarioEntra("@> ", 3);
        limpaTudo();
        //entra a escolha e descriçao
       
         
        if (input == 1) {
            apareceTela(" Você escolheu a Raça: ANÃO!");
             System.out.println(" A raça dos Anões é, uma raça típica e presente nesse mundo, possuindo membros\n" +
"  espalhados por praticamente todos os territórios. Seres baixos, raramente\n" +
"  ultrapassam 1 metro e 50 de altura, porém são mais robustos e\n" +
"  fortes que muitas outras raças. Anões possuem também uma resistência natural superior,\n" +
"  sendo imunes a veneno, seja ele em forma de magia ou em objetos.\n" +
"  \n" +
"  Anões podem viver mais de 400 anos, essa longevidade concede a eles\n" +
"  uma perspectiva sobre o mundo que falta às \n" +
"  raças de menor longevidade, como os humanos e os halflings.\n" +
"\n" +
"  Os anões tem devoção aos deuses dos anões, \n" +
"  aqueles que defendem os ideais anões de serem trabalhadores, \n" +
"  hábeis em combate e devotos à forja. Os anões são determinados e leais, \n" +
"  fiéis à sua palavra e decididos quando agem, às vezes a ponto de serem \n" +
"  teimosos.\n" +
"  Muitos deles têm um forte senso de justiça e\n" +
"  demoram a se esquecer de erros cometidos contra eles.");
            
            telaDesenha(1);
             
            apareceTela(" Gostaria de escolher outra Raça? ");
            System.out.println("(1) Não. ");
            System.out.println("(2) Sim. ");
            input = usuarioEntra("@> ", 2);
              if (input == 1){
                  jogador.raça = 1;
                escolheOpcao();
            }
            escolheRaça();
            
        }if (input == 2) {
            apareceTela("Você escolheu a Raça: ELFO!");
             System.out.println("A Raça dos Elfos é, uma raça antiga, de membros sábios, composta por seres esbeltos,\n" +
"  de orelhas pontiagudas e olhos amarelos. São capazes de ver no meio da\n" +
"  escuridão com perfeição, sendo que não necessitam carregar nenhum tipo de\n" +
"  luz. Eles também vivem em média três vezes mais que os seres humanos, podendo até mesmo \n" +
"  passar de mais de 700 anos.\n" +
"\n" +
"     Apesar de possuírem uma tendência natural ao uso da magia, há muitos \n" +
"   elfos que seguem carreiras inesperadas, como guerreiros, \n" +
"    ou até mesmo ladrões.\n" +
"\n" +
"     A maioria dos elfos, habitam pequenas aldeias florestais\n" +
"  escondidas entre as árvores. Elfos caçam, coletam e\n" +
"  cultivam seus alimentos, e sua perícia em magia os permite\n" +
"  se sustentar sem a necessidade de limpar e arar a terra.\n" +
"  Eles são artesãos talentosos, criando roupas e objetos de\n" +
"  arte.\n" +
"\n" +
"    Assim como os galhos de uma árvore jovem, os elfos\n" +
"  são flexíveis em face do perigo. Eles confiam\n" +
"  primeiramente na diplomacia para resolver as diferenças\n" +
"  antes de partir para a violência.");
               
             telaDesenha(1);
             
            apareceTela(" Gostaria de escolher outra Raça? ");
            System.out.println("(1) Não. ");
            System.out.println("(2) Sim. ");
            input = usuarioEntra("@> ", 2);
              if (input == 1){
                  jogador.raça = 1;
                escolheOpcao();
            }
            escolheRaça();
        } else if (input == 3) {
            apareceTela("Você escolheu a Raça: Tiefling !");
             System.out.println("Os Tieflings derivam de linhagens humanas e, no sentido\n" +
" mais amplo possível, eles ainda parecem humanos. No\n" +
" entanto, sua herança infernal deixou traços claros na sua\n" +
" aparência. Tieflings possuem grandes chifres que\n" +
" possuem os mais diversos formatos: alguns possuem\n" +
" chifres curvos, como um carneiro, outros possuem chifres\n" +
" compridos e finos, como uma gazela, e outros chifres alongados.\n" +
" alguns podem possuir ate mesmo asas.\n" +
"\n" +
"    Os tieflings sobrevivem em pequenas minorias\n" +
" encontradas geralmente em cidades ou vilas humanas, na\n" +
" maioria das vezes em bairros mais barra-pesada desses\n" +
" lugares, onde eles crescem para se tornarem vigaristas,\n" +
" ladrões ou senhores do crime.");
            
               telaDesenha (1);
           
            apareceTela(" Gostaria de escolher outra Raça? ");
            System.out.println("(1) Não.");
            System.out.println("(2) Sim.");
            input = usuarioEntra("@> ", 2);
              if (input == 1){
                 jogador.raça = 3;
               escolheOpcao();
            }
            escolheRaça();
        }
}
 
static void escolheOpcao() throws Exception{
        limpaTudo();
     
        apareceTela(" Agora, escolha uma das Classes abaixo: ");
        System.out.println("(1) " + jogador.Mago[jogador.numAtkMago]);
        System.out.println("(2) " + jogador.Ladino[jogador.numAtkLadino]);
        System.out.println("(3) " + jogador.Monge[jogador.numAtkMonge]);
        // Obter a escolha do jogador
        int input = usuarioEntra("@> ", 3);
        limpaTudo();
        //lidar com ambos os casos
        if (input == 1) {
            apareceTela(" Você escolheu: " + jogador.Mago[jogador.numAtkMago] + "!");
              telaDesenha(1);
             System.out.println("NECROMANTE."
                    + "Características --> Monarca das Sombras.\n "
                    + "Dominador da Magia de Sangue.\n "
                    + "Extremamente inteligente.\n "
                    + "E pode causar medo ou repúdio aos outros.\n ");
     
            
             apareceTela(" Gostaria de escolher outra Classe? ");
             System.out.println("(1) Não.");
             System.out.println("(2) Sim.");
            input = usuarioEntra("@> ", 2);
              if (input == 1){
                  jogador.cla = 1;
               Historias.introNecro();
            }
            escolheOpcao();
            
        } else if (input == 2) {
            apareceTela(" Você escolheu: " + jogador.Ladino[jogador.numAtkLadino] + "!");
            System.out.println("LADINO."
                    + "Características --> Mestre da Furtividade.\n "
                    + "Mestre do Assassinato.\n "
                    + "Ótimo Ladrão.\n "
                    + "Persuasivo.\n ");
          
               apareceTela(" Gostaria de escolher outra Classe? ");
             System.out.println("(1) Não.");
             System.out.println("(2) Sim.");
            input = usuarioEntra("@> ", 2);
              if (input == 1){
                 jogador.cla= 2;
                Historias.introLadino();
            }
            escolheOpcao();
            
        } else if (input == 3) {
            apareceTela(" Você escolheu: " + jogador.Monge[jogador.numAtkMonge] + "!");
              System.out.println("MONGE."
                    + "Características --> Mestre da luta corpo a corpo.\n "
                    + "Mestre em Luta Espiritual.\n "
                    + "Ótimo defensor, \n "
                    + "porém não é dos mais amigáveis, tendo baixo carisma.\n");
            
             apareceTela(" Gostaria de escolher outra Classe? ");
             System.out.println("(1) Não.");
             System.out.println("(2) Sim.");
            input = usuarioEntra("@> ", 2);
              if (input == 1){
                  jogador.cla = 3;
                 Historias.introMonge();
            }
            escolheOpcao();         
        } 
      limpaTudo();
      
    }
      
static void escolheOpcao1() {
       

      apareceTela("Você ganhou um Ataque: ");
        if (jogador.cla == 1) {
            jogador.numAtkMago++;
            System.out.println(jogador.Mago[jogador.numAtkMago]);
            telaDesenha(1);
        } else if (jogador.cla == 2) {
            jogador.numAtkLadino++;
            System.out.println(jogador.Ladino[jogador.numAtkLadino]);
            telaDesenha(1);
        }else if(jogador.cla == 3) {
            jogador.numAtkMonge++;
            System.out.println(jogador.Monge[jogador.numAtkMonge]);
            telaDesenha(1);
        }
        digitaAlgo();
    

        limpaTudo();
      
     
    }
        

    
static void iniciaIntro() throws Exception {
        locais[local] = "Castelo!\n";
        // aparece a introduçao do jogo
        
        Historias.apareceIntroduçaoLadino(); 
       
        
     Historias.apareceHistoria1();
      inimigoMortoVivo = new MortoVivo();
        Combat();
        //verifica se o estaRodando esta verdadeiro, para o jogo continuar
        estaRodando = true;

        jogoSemparar();

    }

static void iniciaIntro2() throws Exception {
        locais[local] = "Castelo!\n";
        // aparece a introduçao do jogo
        
       
        Historias.apareceIntroduçaoNecro();
       
        
   Historias.apareceHistoria1();
    inimigoMortoVivo = new MortoVivo();
        Combat();
        //verifica se o estaRodando esta verdadeiro, para o jogo continuar
        estaRodando = true;

        jogoSemparar();

    }

static void iniciaIntro3() throws Exception {
        locais[local] = "Castelo!\n";
        // aparece a introduçao do jogo
        
        
        Historias.apareceIntroduçaoMonge();
        
       Historias.apareceHistoria1();
        inimigoMortoVivo = new MortoVivo();
        Combat();
        //verifica se o estaRodando esta verdadeiro, para o jogo continuar
        estaRodando = true;

        jogoSemparar();

    }

static void continuaHistoria() throws Exception{
       
      locais[local] = "Dentro da Floresta";
      Historias.apareceHistora2();
      qualCaminho();
      
   }

   
static void irparaEstrada() throws Exception{
      Historias.estradadoCastelo();
       qualCaminhoEsT01();
  }
  
static void irparaEstrada02() throws Exception{
      Historias.depoisdaBatalha01();
              qualCaminhoEsT02();
  }
  
static void andarNaFloresta() throws Exception{
      Historias.continuaFloresta();
      locais[local] = "Dentro da Floresta";
       
       //cria e chama o inimigo aqui
      inimigoAranhaGG = new aranhaGigante();
         Combat2(); 
           estaRodando = true;
          jogoSemparar00();
        
  }
  
static void continuaNaFloresta() throws Exception{
    locais[local] = "Dentro da Floresta";
    Historias.apareceArcnae();
    inimigoArcnae = new Arcnae();
     Combat3();
     estaRodando = true;
    jogoSemparar1();
}
  
static void continuaHistoria2() throws Exception{
        Historias.CidadeRust();
        Historias.EstradaTerra();
        Historias.CabanaAbandonada();
        jogoSemparar3();
        estaRodando = true;
          
    }
   
static void naPonte() throws Exception {
        Historias.Ponte();
        locais[local] = "Ponte de Pedra!\n";
       inimigoLadrao = new Ladrao();
       Combat4();
         estaRodando = true;
       Historias.TavernaWineFord();
         jogoSemparar4();
        estaRodando = true;
    }
    
static void naWater() throws Exception {
         Historias.LoudWater();
        locais[local] = "Cidade!\n";
        inimigoMinota = new Minotauro();
        Combat5();
          estaRodando = true;
        jogoSemparar5();
        
       
    }
      
static void naWater2() throws Exception {
         
        locais[local] = "Cidade!\n";
        
     Historias.LoudWater2();
     inimigoDrg = new Dragao();
       Combat6(); 
        estaRodando = true;
        Historias.Final();
    }
   
   
  
 //%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Menus de escolhas
 
   // mostra o menu durante o jogo
 static void aiMenuHistoria() {

         apareceTela(locais[local]);
        System.out.println("Escolha uma das Ações a seguir:");
        telaDesenha(1);
        System.out.println("(1) Continuar História ?");
        System.out.println("(2) Informações do Personagem ?");
        System.out.println("(3) Usar poção ?\n");
    }

 static void aiMenuEscolhas() {
        System.out.println("Escolha uma das Ações a seguir:");
        telaDesenha(1);
        System.out.println("(1) Ir para a Estrada ?");
        System.out.println("(2) Continuar andando na Floresta ?\n");

    }

 static void aiMenuEscolhasEsT01() {
        System.out.println("Escolha uma das Ações a seguir: ");
        telaDesenha(1);
        System.out.println("(1) Se aproximar dos cadávares? Talvez você encontre algo.");
        System.out.println("(2) Ficar e observar mais um pouco ?\n");

    }

 static void aiMenuEscolhasEsT02() {
        System.out.println("Escolha uma das Ações a seguir:");
        telaDesenha(1);
        System.out.println("(1) Voltar para a Floresta?");
        System.out.println("(2) Ficar e enfrentar seja o que for ?\n");
    }
   
  static void sleep(){
        try {
            Thread.sleep(2000);
        } catch (InterruptedException ex){
        }
    } 
   // $$$$$$$$$$$$$$$ Detalhes do personagem
   

   // >>>>>>>>>>>>>>>>>>>>>>>>>> Qual caminho Pegar <<<<<<<<<<<<<<<<<<<<<<<<<<<  
     
   static  void qualCaminho() throws Exception{
       while(estaRodando){
           aiMenuEscolhas();
           int input = usuarioEntra(" @>@>@>@>@>@>@>@>@>@>@>@>@>@>@>@>@>@> ", 2);
             if(input == 1){
                 Historias.irEstrada();
                 irparaEstrada();
             }else if(input == 2){
                 Historias.continuaFloresta();
                 andarNaFloresta();
            
             }  
             else
                 estaRodando = false;
         }
       }
   
    static  void qualCaminhoEsT01() throws Exception{
       while(estaRodando){
           aiMenuEscolhasEsT01();
           int input = usuarioEntra(" @>@>@>@>@>@>@>@>@>@>@>@>@>@>@>@>@>@> ", 2);
             if(input == 1){
              Historias.aprocCadaver();
              irparaEstrada02();
             }else if(input == 2){
             Historias.ficareVer();
             irparaEstrada02();
             }  
             else
                 estaRodando = false;
         }
    }
    
     static  void qualCaminhoEsT02() throws Exception{
       while(estaRodando){
           aiMenuEscolhasEsT02();
           int input = usuarioEntra(" @>@>@>@>@>@>@>@>@>@>@>@>@>@>@>@>@>@>", 2);
             if(input == 1){
            Historias.voltaFloresta();
            andarNaFloresta();
             }else if(input == 2){
              Historias.ficarEnfrentar();
              jogadorMorre();
            
             }  
             else
                 estaRodando = false;
         }
    }
    
   // @@@@@@@@@@@@@@@@@@  Verifica quando esta rodando e chama
   
     static void jogoSemparar() throws Exception{
         while(estaRodando){ 
            aiMenuHistoria();
             int input = usuarioEntra(" @> ", 3);
             if(input == 1)
                 continuaHistoria();
             else if(input == 2){
                 persoDetalhes();
            
             }else if(input == 3){
                 if(jogador.hp > 0 && jogador.hp < jogador.maxHp){
                     apareceTela("Voce quer usar uma Poçao ?" + "\tQuantidades:" + jogador.pots);
                     System.out.println("(1) Sim \n(2) Nao");
                      input = usuarioEntra("@>@>@>@>@>@>@>@>@>@>@>@>@>@>@>@>@>@> ",2);
                      if(input == 1){
                          jogador.hp = jogador.maxHp;
                          jogador.pots  = jogador.pots - 1;
                          limpaTudo();
                          apareceTela("Voce consumiu uma poçao. sua vida restaurou para.\n " + 
                                        " Sua vida agora está em: " + jogador.maxHp);
                          digitaAlgo();
                      }
                 }else{
                     apareceTela(" Nao pode tomar poçao");
                     digitaAlgo();
                 }
             }
                 
             else
                 estaRodando = false;
         }
     }
      static void jogoSemparar00() throws Exception{
         while(estaRodando){ 
             aiMenuHistoria();
             int input = usuarioEntra(" @> ", 3);
             if(input == 1){
                continuaNaFloresta();
             }else if(input == 2){
                 persoDetalhes();
            
             }else if(input == 3){
                 if(jogador.hp > 0 && jogador.hp < jogador.maxHp){
                     apareceTela("Voce quer usar uma Poçao ?" + "\tQuantidades:" + jogador.pots);
                     System.out.println("(1) Sim \n(2) Nao");
                      input = usuarioEntra("@> ",2);
                      if(input == 1){
                          jogador.hp = jogador.maxHp;
                          jogador.pots  = jogador.pots - 1;
                          limpaTudo();
                          apareceTela("Voce consumiu uma poçao. sua vida restaurou para.\n " + 
                                        " Sua vida agora está em: " + jogador.maxHp);
                          digitaAlgo();
                      }
                 }else{
                     apareceTela(" Nao pode tomar poçao");
                     digitaAlgo();
                 }
             }
                 
             else
                 estaRodando = false;
         }
     }
     
      static void jogoSemparar1() throws Exception{
         while(estaRodando){ 
             aiMenuHistoria();
             int input = usuarioEntra(" @> ", 3);
             if(input == 1){
                continuaHistoria2();
             }else if(input == 2){
                 persoDetalhes();
            
             }else if(input == 3){
                 if(jogador.hp > 0 && jogador.hp < jogador.maxHp){
                     apareceTela("Voce quer usar uma Poçao ?" + "\tQuantidades:" + jogador.pots);
                     System.out.println("(1) Sim \n(2) Nao");
                      input = usuarioEntra("@> ",2);
                      if(input == 1){
                          jogador.hp = jogador.maxHp;
                          jogador.pots  = jogador.pots - 1;
                          limpaTudo();
                          apareceTela("Voce consumiu uma poçao. sua vida restaurou para.\n " + 
                                        " Sua vida agora está em: " + jogador.maxHp);
                          digitaAlgo();
                      }
                 }else{
                     apareceTela(" Nao pode tomar poçao");
                     digitaAlgo();
                 }
             }
                 
             else
                 estaRodando = false;
         }
     }
      
      static  void jogoSemparar2(){
           while(estaRodando){ 
             aiMenuHistoria();
             int input = usuarioEntra(" @> ", 3);
             if(input == 1){
                
             }else if(input == 2){
                 persoDetalhes();
            
             }else if(input == 3){
                 if(jogador.hp > 0 && jogador.hp < jogador.maxHp){
                     apareceTela("Voce quer usar uma Poçao ?" + "\tQuantidades:" + jogador.pots);
                     System.out.println("(1) Sim \n(2) Nao");
                      input = usuarioEntra("@> ",2);
                      if(input == 1){
                          jogador.hp = jogador.maxHp;
                          jogador.pots  = jogador.pots - 1;
                          limpaTudo();
                          apareceTela("Voce consumiu uma poçao. sua vida restaurou para.\n " + 
                                        " Sua vida agora está em: " + jogador.maxHp);
                          digitaAlgo();
                      }
                 }else{
                     apareceTela(" Nao pode tomar poçao");
                     digitaAlgo();
                 }
             }
                 
             else
                 estaRodando = false;
         }
      }
      
      
       static  void jogoSemparar3(){
           while(estaRodando){ 
             aiMenuHistoria();
             int input = usuarioEntra(" @> ", 3);
             if(input == 1){
                
             }else if(input == 2){
                 persoDetalhes();
            
             }else if(input == 3){
                 if(jogador.hp > 0 && jogador.hp < jogador.maxHp){
                     apareceTela("Voce quer usar uma Poçao ?" + "\tQuantidades:" + jogador.pots);
                     System.out.println("(1) Sim \n(2) Nao");
                      input = usuarioEntra("@> ",2);
                      if(input == 1){
                          jogador.hp = jogador.maxHp;
                          jogador.pots  = jogador.pots - 1;
                          limpaTudo();
                          apareceTela("Voce consumiu uma poçao. sua vida restaurou para.\n " + 
                                        " Sua vida agora está em: " + jogador.maxHp);
                          digitaAlgo();
                      }
                 }else{
                     apareceTela(" Nao pode tomar poçao");
                     digitaAlgo();
                 }
             }
                 
             else
                 estaRodando = false;
         }
      }
       
        static  void jogoSemparar4(){
           while(estaRodando){ 
             aiMenuHistoria();
             int input = usuarioEntra(" @> ", 3);
             if(input == 1){
                
             }else if(input == 2){
                 persoDetalhes();
            
             }else if(input == 3){
                 if(jogador.hp > 0 && jogador.hp < jogador.maxHp){
                     apareceTela("Voce quer usar uma Poçao ?" + "\tQuantidades:" + jogador.pots);
                     System.out.println("(1) Sim \n(2) Nao");
                      input = usuarioEntra("@> ",2);
                      if(input == 1){
                          jogador.hp = jogador.maxHp;
                          jogador.pots  = jogador.pots - 1;
                          limpaTudo();
                          apareceTela("Voce consumiu uma poçao. sua vida restaurou para.\n " + 
                                        " Sua vida agora está em: " + jogador.maxHp);
                          digitaAlgo();
                      }
                 }else{
                     apareceTela(" Nao pode tomar poçao");
                     digitaAlgo();
                 }
             }
                 
             else
                 estaRodando = false;
         }
      }
        
         static  void jogoSemparar5(){
           while(estaRodando){ 
             aiMenuHistoria();
             int input = usuarioEntra(" @> ", 3);
             if(input == 1){
                
             }else if(input == 2){
                 persoDetalhes();
            
             }else if(input == 3){
                 if(jogador.hp > 0 && jogador.hp < jogador.maxHp){
                     apareceTela("Voce quer usar uma Poçao ?" + "\tQuantidades:" + jogador.pots);
                     System.out.println("(1) Sim \n(2) Nao");
                      input = usuarioEntra("@> ",2);
                      if(input == 1){
                          jogador.hp = jogador.maxHp;
                          jogador.pots  = jogador.pots - 1;
                          limpaTudo();
                          apareceTela("Voce consumiu uma poçao. sua vida restaurou para.\n " + 
                                        " Sua vida agora está em: " + jogador.maxHp);
                          digitaAlgo();
                      }
                 }else{
                     apareceTela(" Nao pode tomar poçao");
                     digitaAlgo();
                 }
             }
                 
             else
                 estaRodando = false;
         }
      }
      
         // mostra as informaçoes do personagem
   static void persoDetalhes(){
      
        apareceTela("Detalhes do personagem");
       System.out.println(jogador.nome + "\thp: " + jogador.hp + "/" + jogador.maxHp );
       telaDesenha(1);
       System.out.println("Level: " + jogador.level);
       telaDesenha(1);
       System.out.println("Xp:" + jogador.xp);
       telaDesenha(1);
       System.out.println("Poçoes: " + jogador.pots);
       telaDesenha(1);
            if ( jogador.raça == 1) {
            System.out.println("Sua Raça é: Anão " );
            telaDesenha(1);

    } else if ( jogador.raça == 2) {
            System.out.println("Sua Raça é: Elfo ");
            telaDesenha(1);
        } else{
            System.out.println("Sua Raça é: Tiefling " );
            telaDesenha(1);
        }
            
        // mostra tudo que ja foi escolhido
       if (jogador.cla == 1) {
            System.out.println("Classe" + jogador.Mago[jogador.numAtkMago - 1]+ " e ataques aprendidos: " + jogador.Mago[jogador.numAtkMago]);
            telaDesenha(1);
           
        } else if (jogador.cla == 2) {
            System.out.println("Classe" +  jogador.Ladino[jogador.numAtkLadino - 1] +  " e ataques aprendidos: " + jogador.Ladino[jogador.numAtkLadino]);
            telaDesenha(1);
          
        } else{
            System.out.println("Classe" +  jogador.Monge[jogador.numAtkMonge - 1] + " e ataques aprendidos: "  + jogador.Monge[jogador.numAtkMonge]);
            telaDesenha(1);
           
        }  
    }
   
    // ¨¨¨¨¨¨¨¨¨¨¨¨¨¨ Combates ¨¨¨¨¨¨¨¨¨¨¨¨¨¨  
      
   static void Combat(){
       int escAtaque;
      
       if(jogador.cla ==1){
           while(jogador.hp >= 0 && inimigoMortoVivo.hp > 0){
             apareceTela("MortoVivo" + "\tHp: "+ inimigoMortoVivo.hp + "/" + inimigoMortoVivo.maxHp);
              apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp );
              escAtaque = ataqueMago();
              switch (escAtaque) {
                    case 1:
                        System.out.println("Eletricidade surge da sua mão. Você desfere uma carga elétrica\n" 
                                           + " e acerta, em cheio, a criatura à sua frente. \n");
                        inimigoMortoVivo.hp -= 6;
                        break;
                    case 2:
                        System.out.println("Você cria uma mão esquelética fantasmagórica, \n" 
                                           + " que rasga a carne da criatura à sua frente.");
                        inimigoMortoVivo.hp -= 13;
                        break;
                    default:
                        System.out.println("Opção Invalida.");// caso digite outro numero
                        break;
                }
              if(inimigoMortoVivo.hp > 0){
                apareceTela("MortoVivo" + "\tHp: "+ inimigoMortoVivo.hp + "/" + inimigoMortoVivo.maxHp);
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp );
                escAtaque = ataqueMortoVivo();
                 switch (escAtaque) {
                        case 1:
                            System.out.println("O Morto Vivo vem até você, e lhe da uma mordida.\n " 
                                               + ' ' + " Você perdeu 7 pontos de vida. \n");
                            jogador.hp-= 7;
                            break;
                        case 2:
                            System.out.println("O Morto Vivo caminha até você, levanta os\n" 
                                               + " seus braços e o acerta, o seu rosto, em cheio\n" 
                                               + ' ' + "Você perdeu 10 pontos de vida. \n");
                            jogador.hp -= 10;
                            break;
                        case 3:
                            System.out.println("O Morto Vivo recolhe uma pedra e rapidamente\n" + 
                                               " joga-a em sua direção, acertando-o na cabeça.\n" 
                                               + ' ' + " Você perdeu 25 pontos de vida\n ");
                            jogador.hp -= 25;
                            break;
                        default:
                            System.out.println("O Morto Vivo tenta lhe acertar, mas você consegue se esquivar.");
                            break;
                    }
              }else if(jogador.hp <= 0){
                jogadorMorre();
                telaDesenha(1);
            }else{
                System.out.println("O Morto Vivo se decompõe, na sua frente, e desaparece."); 
                jogador.xp += inimigoMortoVivo.xp;
               upGame();
                 jogador.pots += 1; 
                 System.out.println(" \tNarrador: \nLogo após matar o Morto Vivo, o Rei Baldor\n" 
                                       + " joga uma poção para você.");
                telaDesenha(1);
          }
        }
       }else if(jogador.cla == 2){
        while(jogador.hp >= 0 && inimigoMortoVivo.hp > 0){
             apareceTela("MortoVivo" + "\tHp: "+ inimigoMortoVivo.hp + "/" + inimigoMortoVivo.maxHp);
              apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp );
            escAtaque = ataqueLadino();
            switch (escAtaque) {
                    case 1:
                        System.out.println("Você se equipa com o seu arco e dispara uma flecha\n" 
                                           + " contra o seu inimigo, perfurando a sua carne.\n");
                        inimigoMortoVivo.hp-= 16;
                        break;
                    case 2:
                        System.out.println("Você se aproxima do seu alvo, desembainha a sua adaga\n" 
                                           + " e faz um corte, rápido, porém profundo, no seu inimigo\n");
                        inimigoMortoVivo.hp -= 10;
                        break;
                    default:
                        System.out.println("Opção Inválida.");
                        break;
                }
             if(inimigoMortoVivo.hp > 0){
                apareceTela("MortoVivo" + "\tHp: "+ inimigoMortoVivo.hp + "/" + inimigoMortoVivo.maxHp);
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp );
                escAtaque = ataqueMortoVivo();
                 switch (escAtaque) {
                        case 1:
                            System.out.println("O Morto Vivo vem até você, e lhe da uma mordida.\n " 
                                               + ' ' + " Você perdeu 7 pontos de vida. \n");
                            jogador.hp-= 7;
                            break;
                        case 2:
                            System.out.println("O Morto Vivo caminha até você, levanta os\n" 
                                               + " seus braços e o acerta, o seu rosto, em cheio\n" 
                                               + ' ' + "Você perdeu 10 pontos de vida. \n");
                            jogador.hp -= 10;
                            break;
                        case 3:
                            System.out.println("O Morto Vivo recolhe uma pedra e rapidamente\n" + 
                                               " joga-a em sua direção, acertando-o na cabeça.\n" 
                                               + ' ' + " Você perdeu 25 pontos de vida\n ");
                            jogador.hp -= 25;
                            break;
                        default:
                            System.out.println("O Morto Vivo tenta lhe acertar, mas você consegue se esquivar.");
                            break;
                    }
            }else if(jogador.hp <= 0){
                jogadorMorre();
                telaDesenha(1);
            }else{
                System.out.println("O Morto Vivo se decompõe, na sua frente, e desaparece."); 
                jogador.xp += inimigoMortoVivo.xp;
               upGame();
                 jogador.pots += 1; 
                 System.out.println(" \tNarrador: \nLogo após matar o Morto Vivo, o Rei Baldor\n" 
                                       + " joga uma poção para você.");
                telaDesenha(1);
          }
        }
       }else {// monge
           while(jogador.hp >= 0 && inimigoMortoVivo.hp > 0){
             apareceTela("MortoVivo" + "\tHp: "+ inimigoMortoVivo.hp + "/" + inimigoMortoVivo.maxHp);
              apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp );
              escAtaque = ataqueMonge();
                switch (escAtaque) {
                    case 1:
                        System.out.println("Você estende as suas mãos, concentrando seu KI.\n" 
                                           + " Cerra-as e desfere um soco, energizado, no estômago\n" 
                                           + " do seu inimigo.\n");
                        inimigoMortoVivo.hp -= 15;
                        break;
                    case 2:
                        System.out.println("Você corre na direçao do seu inimigo, pula\n" 
                                           + " e o acerta com uma forte voadora em seu rosto\n");
                        inimigoMortoVivo.hp -= 8;
                        break;
                    default:
                        System.out.println("Opção Inválida.");// caso digite outro numero
                        break;
                }
                if(inimigoMortoVivo.hp > 0){
                apareceTela("MortoVivo" + "\tHp: "+ inimigoMortoVivo.hp + "/" + inimigoMortoVivo.maxHp);
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp );
                escAtaque = ataqueMortoVivo();
                 switch (escAtaque) {
                        case 1:
                            System.out.println("O Morto Vivo vem até você, e lhe da uma mordida.\n " 
                                               + ' ' + " Você perdeu 7 pontos de vida. \n");
                            jogador.hp-= 7;
                            break;
                        case 2:
                            System.out.println("O Morto Vivo caminha até você, levanta os\n" 
                                               + " seus braços e o acerta, o seu rosto, em cheio\n" 
                                               + ' ' + "Você perdeu 10 pontos de vida. \n");
                            jogador.hp -= 10;
                            break;
                        case 3:
                            System.out.println("O Morto Vivo recolhe uma pedra e rapidamente\n" + 
                                               " joga-a em sua direção, acertando-o na cabeça.\n" 
                                               + ' ' + " Você perdeu 25 pontos de vida\n ");
                            jogador.hp -= 25;
                            break;
                        default:
                            System.out.println("O Morto Vivo tenta lhe acertar, mas você consegue se esquivar.");
                            break;
                    }
            }else if(jogador.hp <= 0){
                jogadorMorre();
                telaDesenha(1);
            }else{
                System.out.println("O Morto Vivo se decompõe, na sua frente, e desaparece."); 
                jogador.xp += inimigoMortoVivo.xp;
               upGame();
                 jogador.pots += 1; 
                 System.out.println(" \tNarrador: \nLogo após matar o Morto Vivo, o Rei Baldor\n" 
                                       + " joga uma poção para você.");
                telaDesenha(1);
          }
       }
      }
   }
   
   static void Combat2(){
       int escAtaque;
       
        //Mago
    if (jogador.cla == 1) {
            while (jogador.hp >= 0 && inimigoAranhaGG.hp > 0) {
                apareceTela("Aranha Gigante" + "\tHp: " + inimigoAranhaGG.hp );
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp);
                escAtaque = ataqueMago2();
                switch (escAtaque) {
                    case 1:
                        System.out.println("Eletricidade surge da sua mão. Você desfere uma carga elétrica\n" 
                                           + " e acerta, em cheio, a criatura à sua frente. \n");
                        inimigoAranhaGG.hp -= 6;
                        break;
                    case 2:
                        System.out.println("Você cria uma mão esquelética fantasmagórica, \n" 
                                           + " que rasga a carne da criatura à sua frente.");
                        inimigoAranhaGG.hp-= 13;
                        break;
                    case 3:
                        System.out.println("Você levanta as mãos, em movimento de conjuração de feitiço\n" 
                                           + " murmura palavras mágicas, e então, debaixo do seu\n" 
                                           + " adversário, o chão abre e surgem chamas negras, queimando-o.\n");
                        inimigoAranhaGG.hp -= 20;
                        break;
                    default:
                        System.out.println("Opção Inválida.");// caso digite outro numero
                        break;
                }
            if (inimigoAranhaGG.hp > 0) {
                apareceTela("Aranha Gigante" + " Hp: " + inimigoAranhaGG.hp  );
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp);
                escAtaque = ataqueAranhaGG();
                switch (escAtaque) {
                    case 1:
                        System.out.println("A Aranha Gigante pula em sua direção e\n" 
                                           + " bate em você com as suas patas.\n" 
                                           + ' ' + " Você perde 7 pontos de vida. \n");
                        jogador.hp -= 7;
                        break;
                    case 2:
                        System.out.println("A Aranha Gigante cospe veneno em você.\n" 
                                           + ' ' + "Você perde 10 pontos de vida. \n");
                        jogador.hp -= 10;
                        break;
                    case 3:
                        System.out.println("A Aranha Gigante pula, dispara sua teia pegajosa,\n" 
                                           + " prendendo-o, arremessando-o para longe." 
                                           + ' ' + " Você perde 21 pontos de vida.\n ");
                        jogador.hp -= 21;
                        break;
                    default:
                        System.out.println("A Aranha Gigante tenta lhe acertar, mas você consegue se esquivar.");
                        break;
                }
            } else if (jogador.hp <= 0) {
                jogadorMorre();
                telaDesenha(1);
            } else {
                System.out.println("A Aranha Gigante cai morta."); // acabou a luta chama a aventura do jogo ou seja a historia
                  telaDesenha(1);
                jogador.xp += inimigoAranhaGG.xp;
                  telaDesenha(1);
                   telaDesenha(1);
            }
          }// Ladino
    } else if(jogador.cla == 2) {
            while (jogador.hp >= 0 && inimigoAranhaGG.hp > 0) {
                apareceTela("Aranha Gigante" + "\tHp: " + inimigoAranhaGG.hp );
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp);
                escAtaque = ataqueLadino2();
                switch (escAtaque) {
                    case 1:
                        System.out.println("Você se equipa com o seu arco e dispara uma flecha\n" 
                                           + " contra o seu inimigo, perfurando a sua carne.\n");
                        inimigoAranhaGG.hp -= 16;
                        break;
                    case 2:
                        System.out.println("Você se aproxima do seu alvo, desembainha a sua adaga\n" 
                                           + " e faz um corte, rápido, porém profundo, no seu inimigo\n");
                        inimigoAranhaGG.hp -= 10;
                        break;
                    case 3:
                        System.out.println("Você desembainha as suas duas adagas, corre\n" 
                                           + "em direção do inimigo a sua frente\n" 
                                           + " e começa a dançar com as suas adagas,\n" 
                                           + " no que parece uma dança mortal,\n " 
                                           + " rodando sem parar, causando diversos cortes no corpo do\n" 
                                           + " seu inimigo\n");
                         inimigoAranhaGG.hp -= 22;
                        break;
                    default:
                        System.out.println("Opção Inválida.");// caso digite outro numero
                        break;
                }
               if (inimigoAranhaGG.hp > 0) {
                apareceTela("Aranha Gigante" + " Hp: " + inimigoAranhaGG.hp  );
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp);
                escAtaque = ataqueAranhaGG();
                switch (escAtaque) {
                    case 1:
                        System.out.println("A Aranha Gigante pula em sua direção e\n" 
                                           + " bate em você com as suas patas.\n" 
                                           + ' ' + " Você perde 7 pontos de vida. \n");
                        jogador.hp -= 7;
                        break;
                    case 2:
                        System.out.println("A Aranha Gigante cospe veneno em você.\n" 
                                           + ' ' + "Você perde 10 pontos de vida. \n");
                        jogador.hp -= 10;
                        break;
                    case 3:
                        System.out.println("A Aranha Gigante pula, dispara sua teia pegajosa,\n" 
                                           + " prendendo-o, arremessando-o para longe." 
                                           + ' ' + " Você perde 21 pontos de vida.\n ");
                        jogador.hp -= 21;
                        break;
                    default:
                        System.out.println("A Aranha Gigante tenta lhe acertar, mas você consegue se esquivar.");
                        break;
                }
            } else if (jogador.hp <= 0) {
                jogadorMorre();
                telaDesenha(1);
            } else {
                System.out.println("A Aranha Gigante cai morta."); // acabou a luta chama a aventura do jogo ou seja a historia
                 telaDesenha(1);
                jogador.xp += inimigoAranhaGG.xp;
                  telaDesenha(1);
                 telaDesenha(1);
                }
            }
    }else{// monge
            while (jogador.hp >= 0 && inimigoAranhaGG.hp > 0) {
                apareceTela("Aranha Gigante" + "\tHp: " + inimigoAranhaGG.hp);
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp);
                escAtaque = ataqueMonge2();
                switch (escAtaque) {
                    case 1:
                        System.out.println("Você estende as suas mãos, concentrando seu KI.\n" 
                                           + " Cerra-as e desfere um soco, energizado, no estômago\n" 
                                           + " do seu inimigo.\n");
                        inimigoAranhaGG.hp -= 15;
                        break;
                    case 2:
                        System.out.println("Você corre na direção do seu inimigo, pula\n" 
                                           + " e o acerta com uma forte voadora em seu rosto\n");
                        inimigoAranhaGG.hp -= 8;
                        break;
                    case 3:
                        System.out.println("Você se posiciona um passo para trás,\n" 
                                           + " estende uma única mão, cerrada, para frente,\n" 
                                           + " concentrando todo o seu KI.\n" 
                                           + " Se move em direção ao seu inimigo, pula, e\n" 
                                           + " desfere um poderoso soco no inimigo.n");
                        inimigoAranhaGG.hp -= 21;
                        break;
                    default:
                        System.out.println("Opção Inválida.");// caso digite outro numero
                        break;
                } if (inimigoAranhaGG.hp > 0) {
                apareceTela("Aranha Gigante" + " Hp: " + inimigoAranhaGG.hp );
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp);
                escAtaque = ataqueAranhaGG();
                switch (escAtaque) {
                    case 1:
                        System.out.println("A Aranha Gigante pula em sua direção e\n" 
                                           + " bate em você com as suas patas.\n" 
                                           + ' ' + " Você perde 7 pontos de vida. \n");
                        jogador.hp -= 7;
                        break;
                    case 2:
                        System.out.println("A Aranha Gigante cospe veneno em você.\n" 
                                           + ' ' + "Você perde 10 pontos de vida. \n");
                        jogador.hp -= 10;
                        break;
                    case 3:
                        System.out.println("A Aranha Gigante pula, dispara sua teia pegajosa,\n" 
                                           + " prendendo-o, arremessando-o para longe." 
                                           + ' ' + " Você perde 21 pontos de vida.\n ");
                        jogador.hp -= 21;
                        break;
                    default:
                        System.out.println("A Aranha Gigante tenta lhe acertar, mas você consegue se esquivar.");
                        break;
                }
            } else if (jogador.hp <= 0) {
                jogadorMorre();
                telaDesenha(1);
            } else {
                System.out.println("A Aranha Gigante cai morta"); // acabou a luta chama a aventura do jogo ou seja a historia
                 telaDesenha(1);
                jogador.xp += inimigoAranhaGG.xp;
                  telaDesenha(1);
                telaDesenha(1);
                }
            }
    }
   }
    
   static void Combat3(){
        int escAtaque;
 
        //Mago
    if (jogador.cla == 1) {
            while (jogador.hp >= 0 && inimigoArcnae.hp > 0) {
                apareceTela("Aracnae" + "\tHp: " + inimigoArcnae.hp );
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp);
                escAtaque = ataqueMago2();
                switch (escAtaque) {
                    case 1:
                        System.out.println("Eletricidade surge da sua mão. Você desfere uma carga elétrica\n" 
                                           + " e acerta, em cheio, a criatura à sua frente. \n");
                       inimigoArcnae.hp -= 6 + 4;
                        break;
                    case 2:
                        System.out.println("Você cria uma mão esquelética fantasmagórica, \n" 
                                           + " que rasga a carne da criatura à sua frente.");
                        inimigoArcnae.hp -= 13 + 4;
                        break;
                    case 3:
                        System.out.println("Você levanta as mãos, em movimento de conjuração de feitiço\n" 
                                           + " murmura palavras mágicas, e então, debaixo do seu\n" 
                                           + " adversário, o chão abre e surgem chamas negras, queimando-o.\n");
                        inimigoArcnae.hp -= 20 + 4;
                        break;
                    default:
                        System.out.println("Opção Inválida.");// caso digite outro numero
                        break;
                }
            if (inimigoArcnae.hp > 0) {
                apareceTela("Aracnae" + " Hp: " + inimigoArcnae.hp  );
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp);
                escAtaque = ataqueAracnae();
                switch (escAtaque) {
                    case 1:
                        System.out.println("A Aracnae estende as suas garras e delas\n" 
                                           + " cristais de gelo voam em sua direção, perfurando-o." 
                                           + ' ' + " Você perdeu 18 pontos de vida. \n");
                        jogador.hp -= 18;
                        break;
                    case 2:
                        System.out.println("A Aracnae a sopra veneno em você." 
                                           + ' ' + " Você perdeu 10 pontos de vida. \n");
                        jogador.hp -= 10;
                        break;
                    case 3:
                        System.out.println("A Aracnae te agarra, e se aproxima para lhe dar um beijo\n" 
                                           + " fatal, com muito ácido e veneno." 
                                           + ' ' + " Voce perdeu 25 pontos de vida.\n ");
                        jogador.hp -= 25;
                        break;
                    default:
                        System.out.println("A Aracnae tenta lhe acertar, mas você consegue se esquivar.");
                        break;
                }
            } else if (jogador.hp <= 0) {
                jogadorMorre();
                telaDesenha(1);
            } else {
                System.out.println("A Aracnae cai morta."); // acabou a luta chama a aventura do jogo ou seja a historia
                  telaDesenha(1);
                jogador.xp += inimigoArcnae.xp;
                  telaDesenha(1);
                  jogador.pots += +1;
                  System.out.println(" \tNarrador: \nApós a sua dura batalha contra Aracne,\n" 
                                     + " você vasculha as redondezas e acha uma poção.");
                  upGame();
                telaDesenha(1);
            }
          }// Ladino
    } else if(jogador.cla == 2) {
            while (jogador.hp >= 0 && inimigoArcnae.hp > 0) {
                apareceTela("Aracnae" + "\tHp: " + inimigoArcnae.hp );
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp);
                escAtaque = ataqueLadino2();
                switch (escAtaque) {
                    case 1:
                        System.out.println("Você se equipa com o seu arco e dispara uma flecha\n" 
                                           + " contra o seu inimigo, perfurando a sua carne.\n");
                       inimigoArcnae.hp -= 16 + 4;
                        break;
                    case 2:
                        System.out.println("Você se aproxima do seu alvo, desembainha a sua adaga\n" 
                                           + " e faz um corte, rápido, porém profundo, no seu inimigo\n");
                        inimigoArcnae.hp -= 10 + 4;
                        break;
                    case 3:
                        System.out.println("Você desembainha as suas duas adagas, corre\n" 
                                           + "em direção do inimigo a sua frente\n" 
                                           + " e começa a dançar com as suas adagas,\n" 
                                           + " no que parece uma dança mortal,\n " 
                                           + " rodando sem parar, causando diversos cortes no corpo do\n" 
                                           + " seu inimigo\n");
                         inimigoArcnae.hp -= 22 + 4;
                        break;
                    default:
                        System.out.println("Opção Inválida.");// caso digite outro numero
                        break;
                }
                if (inimigoArcnae.hp > 0) {
                apareceTela("Aracnae" + " Hp: " + inimigoArcnae.hp  );
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp);
                escAtaque = ataqueAracnae();
                switch (escAtaque) {
                    case 1:
                        System.out.println("A Aracnae estende as suas garras e delas\n" 
                                           + " cristais de gelo voam em sua direção, perfurando-o." 
                                           + ' ' + " Você perdeu 18 pontos de vida. \n");
                        jogador.hp -= 18;
                        break;
                    case 2:
                        System.out.println("A Aracnae a sopra veneno em você." 
                                           + ' ' + " Você perdeu 10 pontos de vida. \n");
                        jogador.hp -= 10;
                        break;
                    case 3:
                        System.out.println("A Aracnae te agarra, e se aproxima para lhe dar um beijo\n" 
                                           + " fatal, com muito ácido e veneno." 
                                           + ' ' + " Voce perdeu 25 pontos de vida.\n ");
                        jogador.hp -= 25;
                        break;
                    default:
                        System.out.println("A Aracnae tenta lhe acertar, mas você consegue se esquivar.");
                        break;
                }
            } else if (jogador.hp <= 0) {
                jogadorMorre();
                telaDesenha(1);
            } else {
                System.out.println("A Aracnae cai morta."); // acabou a luta chama a aventura do jogo ou seja a historia
                  telaDesenha(1);
                jogador.xp += inimigoArcnae.xp;
                  telaDesenha(1);
                  jogador.pots += +1;
                  upGame();
                   System.out.println(" \tNarrador: \nApós a sua dura batalha contra Aracne,\n" 
                                     + " você vasculha as redondezas e acha uma poção.");
                telaDesenha(1);
                }
            }
    }else{// monge
            while (jogador.hp >= 0 && inimigoArcnae.hp > 0) {
                apareceTela("Aracnae" + "\tHp: " + inimigoArcnae.hp);
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" +jogador. maxHp);
                escAtaque = ataqueMonge2();
                switch (escAtaque) {
                    case 1:
                        System.out.println("Você estende as suas mãos, concentrando seu KI.\n" 
                                           + " Cerra-as e desfere um soco, energizado, no estômago\n" 
                                           + " do seu inimigo.\n");
                       inimigoArcnae.hp -= 15 + 4;
                        break;
                    case 2:
                        System.out.println("Você corre na direção do seu inimigo, pula\n" 
                                           + " e o acerta com uma forte voadora em seu rosto\n");
                        inimigoArcnae.hp -= 8 + 4;
                        break;
                    case 3:
                        System.out.println("Você se posiciona um passo para trás,\n" 
                                           + " estende uma única mão, cerrada, para frente,\n" 
                                           + " concentrando todo o seu KI.\n" 
                                           + " Se move em direção ao seu inimigo, pula, e\n" 
                                           + " desfere um poderoso soco no inimigo.n");
                        inimigoArcnae.hp -= 21 +4;
                        break;
                    default:
                        System.out.println("Opção Inválida.");// caso digite outro numero
                        break;
                } if (inimigoArcnae.hp> 0) {
                apareceTela("Aracnae" + " Hp: " + inimigoArcnae.hp  );
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp);
                escAtaque = ataqueAracnae();
                switch (escAtaque) {
                    case 1:
                        System.out.println("A Aracnae estende as suas garras e delas\n" 
                                           + " cristais de gelo voam em sua direção, perfurando-o." 
                                           + ' ' + " Você perdeu 18 pontos de vida. \n");
                        jogador.hp -= 18;
                        break;
                    case 2:
                        System.out.println("A Aracnae a sopra veneno em você." 
                                           + ' ' + " Você perdeu 10 pontos de vida. \n");
                        jogador.hp -= 10;
                        break;
                    case 3:
                        System.out.println("A Aracnae te agarra, e se aproxima para lhe dar um beijo\n" 
                                           + " fatal, com muito ácido e veneno." 
                                           + ' ' + " Voce perdeu 25 pontos de vida.\n ");
                        jogador.hp -= 25;
                        break;
                    default:
                        System.out.println("A Aracnae tenta lhe acertar, mas você consegue se esquivar.");
                        break;
                }
            } else if (jogador.hp <= 0) {
                jogadorMorre();
                telaDesenha(1);
            } else {
                System.out.println("A Aracnae cai morta."); // acabou a luta chama a aventura do jogo ou seja a historia
                  telaDesenha(1);
                jogador.xp += inimigoArcnae.xp;
                  telaDesenha(1);
                  jogador.pots += +1;
                  System.out.println(" \tNarrador: \nApós a sua dura batalha contra Aracne,\n" 
                                     + " você vasculha as redondezas e acha uma poção.");
                  upGame();
                telaDesenha(1);
                }
            }
    }
    }
   
   static  void Combat4(){
       int escAtaque;
        
    if (jogador.cla == 1) {
            while (jogador.hp >= 0 && inimigoLadrao.hp > 0) {
                apareceTela("Ladrão" + "\tHp: " + inimigoLadrao.hp );
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp);
                escAtaque = ataqueMago2();
                switch (escAtaque) {
                    case 1:
                        System.out.println("Eletricidade surge da sua mão. Você desfere uma carga elétrica\n" 
                                           + " e acerta, em cheio, a criatura à sua frente. \n");
                       inimigoLadrao.hp -= 6 + 4 ;
                        break;
                    case 2:
                        System.out.println("Você cria uma mão esquelética fantasmagórica, \n" 
                                           + " que rasga a carne da criatura à sua frente.");
                        inimigoLadrao.hp -= 13 + 4;
                        break;
                    case 3:
                        System.out.println("Você levanta as mãos, em movimento de conjuração de feitiço\n" 
                                           + " murmura palavras mágicas, e então, debaixo do seu\n" 
                                           + " adversário, o chão abre e surgem chamas negras, queimando-o.\n");
                        inimigoLadrao.hp -= 20 + 4;
                        break;
                    default:
                        System.out.println("Opção Inválida.");// caso digite outro numero
                        break;
                }
            if (inimigoLadrao.hp> 0) {
                apareceTela("Ladrão" + " Hp: " + inimigoLadrao.hp);
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp);
                escAtaque = ataqueLadrao();
                switch (escAtaque) {
                    case 1:
                        System.out.println("O Ladrão puxa o seu arco e mira com\n" 
                                           + " uma flecha envenenada em você.\n" 
                                           + ' ' + " Você perdeu 25 pontos de vida.\n");
                        jogador.hp -= 25;
                        break;
                    case 2:
                        System.out.println("O Ladrão lança duas adagas em você, perfurando-o.\n" 
                                           + ' ' + " Você perdeu 20 pontos de vida.\n");
                        jogador.hp -= 20;
                        break;
                    case 3:
                        System.out.println("O Ladrão saca as suas adagas e pula em sua\n" 
                                           + " direção, causando um corte, transversal, em seu peito.\n" 
                                           + ' ' + " Você perdeu 32 pontos de vida.\n ");
                        jogador.hp -= 32;
                        break;
                    default:
                        System.out.println("O Ladrão tenta lhe acertar, mas você consegue se esquivar.");
                        break;
                }
            } else if (jogador.hp <= 0) {
                jogadorMorre();
                telaDesenha(1);
            } else {
                System.out.println("O Ladrão cai morto."); // acabou a luta chama a aventura do jogo ou seja a historia
                  telaDesenha(1);
                jogador.xp += inimigoLadrao.xp;
                  telaDesenha(1);
                  jogador.pots += +1;
                   System.out.println(" \tNarrador: \nLogo apás matar o ladrão, você\n" 
                                      + " vasculha seu corpo e encontra uma poção. ");
                telaDesenha(1);
            }
          }// Ladino
    }else if(jogador.cla == 2) {
            while (jogador.hp >= 0 && inimigoLadrao.hp > 0) {
                apareceTela("Ladrão" + "\tHp: " + inimigoLadrao.hp );
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp);
                escAtaque = ataqueLadino2();
                switch (escAtaque) {
                    case 1:
                        System.out.println("Você se equipa com o seu arco e dispara uma flecha\n" 
                                           + " contra o seu inimigo, perfurando a sua carne.\n");
                      inimigoLadrao.hp -= 16 + 4;
                        break;
                    case 2:
                        System.out.println("Você se aproxima do seu alvo, desembainha a sua adaga\n" 
                                           + " e faz um corte, rápido, porém profundo, no seu inimigo\n");
                       inimigoLadrao.hp -= 10 + 4;
                        break;
                    case 3:
                        System.out.println("Você desembainha as suas duas adagas, corre\n" 
                                           + "em direção do inimigo a sua frente\n" 
                                           + " e começa a dançar com as suas adagas,\n" 
                                           + " no que parece uma dança mortal,\n " 
                                           + " rodando sem parar, causando diversos cortes no corpo do\n" 
                                           + " seu inimigo\n");
                         inimigoLadrao.hp -= 22 + 4;
                        break;
                    default:
                        System.out.println("Opção Inválida.");// caso digite outro numero
                        break;
                }
                if (inimigoLadrao.hp> 0) {
                apareceTela("Ladrão" + " Hp: " + inimigoLadrao.hp);
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp);
                escAtaque = ataqueLadrao();
                switch (escAtaque) {
                    case 1:
                        System.out.println("O Ladrão puxa o seu arco e mira com\n" 
                                           + " uma flecha envenenada em você.\n" 
                                           + ' ' + " Você perdeu 25 pontos de vida.\n");
                        jogador.hp -= 25;
                        break;
                    case 2:
                        System.out.println("O Ladrão lança duas adagas em você, perfurando-o.\n" 
                                           + ' ' + " Você perdeu 20 pontos de vida.\n");
                        jogador.hp -= 20;
                        break;
                    case 3:
                        System.out.println("O Ladrão saca as suas adagas e pula em sua\n" 
                                           + " direção, causando um corte, transversal, em seu peito.\n" 
                                           + ' ' + " Você perdeu 32 pontos de vida.\n ");
                        jogador.hp -= 32;
                        break;
                    default:
                        System.out.println("O Ladrão tenta lhe acertar, mas você consegue se esquivar.");
                        break;
                }
            } else if (jogador.hp <= 0) {
                jogadorMorre();
                telaDesenha(1);
            } else {
                System.out.println("O Ladrão cai morto."); // acabou a luta chama a aventura do jogo ou seja a historia
                  telaDesenha(1);
                jogador.xp += inimigoLadrao.xp;
                  telaDesenha(1);
                  jogador.pots += +1;
                   System.out.println(" \tNarrador: \nLogo apás matar o ladrão, você\n" 
                                      + " vasculha seu corpo e encontra uma poção. ");
                telaDesenha(1);
                }
            }
    }else{// monge
            while (jogador.hp >= 0 && inimigoLadrao.hp > 0) {
                apareceTela("Ladrão" + "\tHp: " + inimigoLadrao.hp);
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp);
                escAtaque = ataqueMonge2();
                switch (escAtaque) {
                    case 1:
                        System.out.println("Você estende as suas mãos, concentrando seu KI.\n" 
                                           + " Cerra-as e desfere um soco, energizado, no estômago\n" 
                                           + " do seu inimigo.\n");
                        inimigoLadrao.hp -= 15 + 4;
                        break;
                    case 2:
                        System.out.println("Você corre na direção do seu inimigo, pula\n" 
                                           + " e o acerta com uma forte voadora em seu rosto\n");
                       inimigoLadrao.hp -= 8 + 4;
                        break;
                    case 3:
                        System.out.println("Você se posiciona um passo para trás,\n" 
                                           + " estende uma única mão, cerrada, para frente,\n" 
                                           + " concentrando todo o seu KI.\n" 
                                           + " Se move em direção ao seu inimigo, pula, e\n" 
                                           + " desfere um poderoso soco no inimigo.n");
                        inimigoLadrao.hp -= 21 +4;
                        break;
                    default:
                        System.out.println("Opção Inválida.");// caso digite outro numero
                        break;
                } if (inimigoLadrao.hp > 0) {
                apareceTela("Ladrão" + " Hp: " + inimigoLadrao.hp  );
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp);
                escAtaque = ataqueLadrao();
                switch (escAtaque) {
                    case 1:
                        System.out.println("O Ladrão puxa o seu arco e mira com\n" 
                                           + " uma flecha envenenada em você.\n" 
                                           + ' ' + " Você perdeu 25 pontos de vida.\n");
                        jogador.hp -= 25;
                        break;
                    case 2:
                        System.out.println("O Ladrão lança duas adagas em você, perfurando-o.\n" 
                                           + ' ' + " Você perdeu 20 pontos de vida.\n");
                        jogador.hp -= 20;
                        break;
                    case 3:
                        System.out.println("O Ladrão saca as suas adagas e pula em sua\n" 
                                           + " direção, causando um corte, transversal, em seu peito.\n" 
                                           + ' ' + " Você perdeu 32 pontos de vida.\n ");
                        jogador.hp -= 32;
                        break;
                    default:
                        System.out.println("O Ladrão tenta lhe acertar, mas você consegue se esquivar.");
                        break;
                }
            } else if (jogador.hp <= 0) {
                jogadorMorre();
                telaDesenha(1);
            } else {
                System.out.println("O Ladrão cai morto"); // acabou a luta chama a aventura do jogo ou seja a historia
                  telaDesenha(1);
                jogador.xp += inimigoLadrao.xp;
                  telaDesenha(1);
                  jogador.pots += +1;
                   System.out.println(" \tNarrador: \nLogo apás matar o ladrão, você\n" 
                                      + " vasculha seu corpo e encontra uma poção. ");
                telaDesenha(1);
                }
            }
    }
}
   
   static void Combat5(){
       int escAtaque;
        
       if (jogador.cla == 1) {
            while (jogador.hp >= 0 && inimigoMinota.hp > 0) {
                apareceTela("Minotauro" + "\tHp: " + inimigoMinota.hp );
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp);
                escAtaque = ataqueMago2();
                switch (escAtaque) {
                    case 1:
                        System.out.println("Eletricidade surge da sua mão. Você desfere uma carga elétrica\n" 
                                           + " e acerta, em cheio, a criatura à sua frente. \n");
                        inimigoMinota.hp -= 6 + 4 ;
                        break;
                    case 2:
                        System.out.println("Você cria uma mão esquelética fantasmagórica, \n" 
                                           + " que rasga a carne da criatura à sua frente.");
                        inimigoMinota.hp -= 13 + 4;
                        break;
                    case 3:
                        System.out.println("Você levanta as mãos, em movimento de conjuração de feitiço\n" 
                                           + " murmura palavras mágicas, e então, debaixo do seu\n" 
                                           + " adversário, o chão abre e surgem chamas negras, queimando-o.\n");
                        inimigoMinota.hp -= 20 + 4;
                        break;
                    default:
                        System.out.println("Opção Inválida.");// caso digite outro numero
                        break;
                }
            if  (inimigoMinota.hp> 0) {
                apareceTela("Minotauro" + " Hp: " + inimigoMinota.hp  );
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp);
                escAtaque = ataqueMino();
                switch (escAtaque) {
                    case 1:
                        System.out.println("O Minotauro puxa o seu machado, e desfere um\n" 
                                           + " poderoso golpe em você.\n" 
                                           + ' ' + "Você perdeu 25 pontos de vida.\n");
                        jogador.hp -= 25;
                        break;
                    case 2:
                        System.out.println("O Minotauro cerra o seu punho e lhe desfere um soco.\n" 
                                           + ' ' + " Você perdeu 10 pontos de vida.\n");
                        jogador.hp -= 10;
                        break;
                    case 3:
                        System.out.println("O Minotauro se abaixa, e corre em sua direção com os\n" 
                                           + " chifres apontados para você, acertando-o em cheio.\n"
                                           + ' ' + " Você perdeu 28 pontos de vida.\n ");
                        jogador.hp -= 28;
                        break;
                    default:
                        System.out.println("O Minotauro tenta lhe acertar, mas você consegue se esquivar.");
                        break;
                }
            } else if (jogador.hp <= 0) {
                jogadorMorre();
                telaDesenha(1);
            } else {
                System.out.println("O Minotauro cai morto."); // acabou a luta chama a aventura do jogo ou seja a historia
                  telaDesenha(1);
                jogador.xp += inimigoMinota.xp;
                  telaDesenha(1);
                   upGame();
                 jogador.pots += +1;
                   System.out.println(" \tNarrador: \nLogo após matar o Minotauro, você\n" 
                                      + " se direciona à uma casa destruída e acha uma poção caida.");
                telaDesenha(1);
            }
          }// Ladino
     }else if(jogador.cla == 2) {
            while (jogador.hp >= 0 && inimigoMinota.hp > 0) {
                apareceTela("Minotauro" + "\tHp: " + inimigoMinota.hp );
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp);
                escAtaque = ataqueLadino2();
                switch (escAtaque) {
                    case 1:
                        System.out.println("Você se equipa com o seu arco e dispara uma flecha\n" 
                                           + " contra o seu inimigo, perfurando a sua carne.\n");
                       inimigoMinota.hp -= 16 + 4;
                        break;
                    case 2:
                        System.out.println("Você se aproxima do seu alvo, desembainha a sua adaga\n" 
                                           + " e faz um corte, rápido, porém profundo, no seu inimigo\n");
                        inimigoMinota.hp -= 10 + 4;
                        break;
                    case 3:
                        System.out.println("Você desembainha as suas duas adagas, corre\n" 
                                           + "em direção do inimigo a sua frente\n" 
                                           + " e começa a dançar com as suas adagas,\n" 
                                           + " no que parece uma dança mortal,\n " 
                                           + " rodando sem parar, causando diversos cortes no corpo do\n" 
                                           + " seu inimigo\n");
                         inimigoMinota.hp-= 22 + 4;
                        break;
                    default:
                        System.out.println("Opção Inválida.");// caso digite outro numero
                        break;
                }if  (inimigoMinota.hp> 0) {
                apareceTela("Minotauro" + " Hp: " + inimigoMinota.hp  );
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp);
                escAtaque = ataqueMino();
                switch (escAtaque) {
                     case 1:
                        System.out.println("O Minotauro puxa o seu machado, e desfere um\n" 
                                           + " poderoso golpe em você.\n" 
                                           + ' ' + "Você perdeu 25 pontos de vida.\n");
                        jogador.hp -= 25;
                        break;
                    case 2:
                        System.out.println("O Minotauro cerra o seu punho e lhe desfere um soco.\n" 
                                           + ' ' + " Você perdeu 10 pontos de vida.\n");
                        jogador.hp -= 10;
                        break;
                    case 3:
                        System.out.println("O Minotauro se abaixa, e corre em sua direção com os\n" 
                                           + " chifres apontados para você, acertando-o em cheio.\n"
                                           + ' ' + " Você perdeu 28 pontos de vida.\n ");
                        jogador.hp -= 28;
                        break;
                    default:
                        System.out.println("O Minotauro tenta lhe acertar, mas você consegue se esquivar.");
                        break;
                }
            } else if (jogador.hp <= 0) {
                jogadorMorre();
                telaDesenha(1);
            } else {
                System.out.println("O Minotauro cai morto."); // acabou a luta chama a aventura do jogo ou seja a historia
                  telaDesenha(1);
                jogador.xp += inimigoMinota.xp;
                  telaDesenha(1);
                  jogador.pots += +1;
                  upGame();
                   System.out.println(" \tNarrador: \nLogo após matar o Minotauro, você\n" 
                                      + " se direciona à uma casa destruída e acha uma poção caida.");
                telaDesenha(1);
                }
            }
    }else{// monge
            while (jogador.hp >= 0 && inimigoMinota.hp > 0) {
                apareceTela("Minotauro" + "\tHp: " + inimigoMinota.hp);
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp);
                escAtaque = ataqueMonge2();
                switch (escAtaque) {
                    case 1:
                        System.out.println("Você estende as suas mãos, concentrando seu KI.\n" 
                                           + " Cerra-as e desfere um soco, energizado, no estômago\n" 
                                           + " do seu inimigo.\n");
                        inimigoMinota.hp -= 15 + 4;
                        break;
                    case 2:
                        System.out.println("Você corre na direção do seu inimigo, pula\n" 
                                           + " e o acerta com uma forte voadora em seu rosto\n");
                        inimigoMinota.hp -= 8 + 4;
                        break;
                    case 3:
                        System.out.println("Você se posiciona um passo para trás,\n" 
                                           + " estende uma única mão, cerrada, para frente,\n" 
                                           + " concentrando todo o seu KI.\n" 
                                           + " Se move em direção ao seu inimigo, pula, e\n" 
                                           + " desfere um poderoso soco no inimigo.n");
                        inimigoMinota.hp -= 21 +4;
                        break;
                    default:
                        System.out.println("Opção Inválida.");// caso digite outro numero
                        break;
                } if  (inimigoMinota.hp> 0) {
                apareceTela("Minotauro" + " Hp: " + inimigoMinota.hp  );
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp);
                escAtaque = ataqueMino();
                switch (escAtaque) {
                    case 1:
                        System.out.println("O Minotauro puxa o seu machado, e desfere um\n" 
                                           + " poderoso golpe em você.\n" 
                                           + ' ' + "Você perdeu 25 pontos de vida.\n");
                        jogador.hp -= 25;
                        break;
                    case 2:
                        System.out.println("O Minotauro cerra o seu punho e lhe desfere um soco.\n" 
                                           + ' ' + " Você perdeu 10 pontos de vida.\n");
                        jogador.hp -= 10;
                        break;
                    case 3:
                        System.out.println("O Minotauro se abaixa, e corre em sua direção com os\n" 
                                           + " chifres apontados para você, acertando-o em cheio.\n"
                                           + ' ' + " Você perdeu 28 pontos de vida.\n ");
                        jogador.hp -= 28;
                        break;
                    default:
                        System.out.println("O Minotauro tenta lhe acertar, mas você consegue se esquivar.");
                        break;
                }
            } else if (jogador.hp <= 0) {
                jogadorMorre();
                telaDesenha(1);
            } else {
                System.out.println("O Minotauro cai morto."); // acabou a luta chama a aventura do jogo ou seja a historia
                  telaDesenha(1);
                jogador.xp += inimigoMinota.xp;
                  telaDesenha(1);
                 jogador.pots += +1;
                  upGame();
                   System.out.println(" \tNarrador: \nLogo após matar o Minotauro, você\n" 
                                      + " se direciona à uma casa destruída e acha uma poção caida.");
                telaDesenha(1);
                }
            }
    }
       
   }
     
    static void Combat6(){
       int escAtaque;
       
          if (jogador.cla == 1) {
            while (jogador.hp >= 0 && inimigoDrg.hp > 0) {
                apareceTela("Dragão Ancião" + "\tHp: " + inimigoDrg.hp );
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp);
                escAtaque = ataqueMago3();
                switch (escAtaque) {
                    case 1:
                        System.out.println("Você levanta suas mãos para o céu, murmura\n" 
                                           + " palavras mágicas, seus olhos brilham, com uma\n" 
                                           + " forte luz, e do céu, um enorme meteoro cai do céu,\n" 
                                           + " acertando seu inimigo em cheio.\n");
                        inimigoDrg.hp -= 45 + 4 ;
                        break;
                    case 2:
                        System.out.println("Você cria uma mão esquelética fantasmagórica, \n" 
                                           + " que rasga a carne da criatura à sua frente.");
                        inimigoDrg.hp -= 13 + 4;
                        break;
                    case 3:
                        System.out.println("Você levanta as mãos, em movimento de conjuração de feitiço\n" 
                                           + " murmura palavras mágicas, e então, debaixo do seu\n" 
                                           + " adversário, o chão abre e surgem chamas negras, queimando-o.\n");
                        inimigoDrg.hp -= 20 + 4;
                        break;
                    default:
                        System.out.println("Opção Inválida.");// caso digite outro numero
                        break;
                }
            if (inimigoDrg.hp> 0) {
                apareceTela("Dragão Ancião" + " Hp: " + inimigoDrg.hp  );
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp);
                escAtaque = ataqueDrg();
                switch (escAtaque) {
                    case 1:
                        System.out.println("O Dragão Ancião te ingnora.\n");
                        
                        break;
                    case 2:
                        System.out.println("O Dragão Ancião continua te ingorando!\n");
                        break;
                    case 3:
                        System.out.println("O Dragão Ancião continua te ingorando!\n");
                        break;
                    case 4:
                        System.out.println("O Dragãoo Ancião cansa de olhar para você e\n" 
                                           + " ruge, soltando um breff, que te derrete." + " Você morreu!");
                        jogador.hp-= 400;
                        break;
                    default:
                        System.out.println("O Dragão Ancião tenta lhe acertar, mas você consegue se esquivar.");
                        break;
                }
            } else if (jogador.hp <= 0) {
                jogadorMorre();
                telaDesenha(1);
            } else {
                System.out.println("O Dragão Ancião cai morto."); // acabou a luta chama a aventura do jogo ou seja a historia
                  telaDesenha(1);
            }
          }// Ladino
     }else if(jogador.cla == 2) {
            while (jogador.hp >= 0 && inimigoDrg.hp > 0) {
                apareceTela("Dragão Ancião" + "\tHp: " + inimigoDrg.hp );
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp);
                escAtaque = ataqueLadino3();
                switch (escAtaque) {
                    case 1:
                        System.out.println("Você se equipa com o seu arco e dispara uma flecha\n" 
                                           + " contra o seu inimigo, perfurando a sua carne.\n");
                       inimigoDrg.hp -= 16 + 4;
                        break;
                    case 2:
                        System.out.println("Você corre em direção do alvo, desembainha as suas\n"
                                           + " adagas envenenadas e, crava-as, no corpo do seu\n" 
                                           + " inimigo.\n");
                        inimigoDrg.hp -= 35 + 4;
                        break;
                    case 3:
                        System.out.println("Você desembainha as suas duas adagas, corre\n" 
                                           + "em direção do inimigo a sua frente\n" 
                                           + " e começa a dançar com as suas adagas,\n" 
                                           + " no que parece uma dança mortal,\n " 
                                           + " rodando sem parar, causando diversos cortes no corpo do\n" 
                                           + " seu inimigo\n");
                         inimigoDrg.hp-= 22 + 4;
                        break;
                    default:
                        System.out.println("Opção Inválida.");// caso digite outro numero
                        break;
                }if (inimigoDrg.hp> 0) {
                apareceTela("Dragão Ancião" + " Hp: " + inimigoDrg.hp  );
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp);
                escAtaque = ataqueDrg();
                switch (escAtaque) {
                    case 1:
                        System.out.println("O Dragão Ancião te ingnora.\n");
                        
                        break;
                    case 2:
                        System.out.println("O Dragão Ancião continua te ingorando!\n");
                        break;
                    case 3:
                        System.out.println("O Dragão Ancião continua te ingorando!\n");
                        break;
                    case 4:
                        System.out.println("O Dragãoo Ancião cansa de olhar para você e\n" 
                                           + " ruge, soltando um breff, que te derrete." + " Você morreu!");
                        jogador.hp -= 400;
                        break;
                    default:
                        System.out.println("O Dragão Ancião tenta lhe acertar, mas você consegue se esquivar.");
                        break;
                }
            } else if (jogador.hp <= 0) {
                jogadorMorre();
                telaDesenha(1);
            } else {
                System.out.println("O Dragão Ancião cai morto."); // acabou a luta chama a aventura do jogo ou seja a historia
                  telaDesenha(1);
                }
            }
    }else{// monge
            while (jogador.hp >= 0 && inimigoDrg.hp > 0) {
                apareceTela("Dragão Ancião" + "\tHp: " + inimigoDrg.hp);
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp);
                escAtaque = ataqueMonge3();
                switch (escAtaque) {
                    case 1:
                        System.out.println("Você estende as suas mãos, concentrando seu KI.\n" 
                                           + " Cerra-as e desfere um soco, energizado, no estômago\n" 
                                           + " do seu inimigo.\n");
                        inimigoDrg.hp -= 15 + 4;
                        break;
                    case 2:
                        System.out.println("Você concentra toda a sua energia e Ki em seu corpo,\n" 
                                           + " movimenta os braços em postura de luta, percorrendo\n" 
                                           + " o espaço em velocidade, salta em frente ao inimigo e\n" 
                                           + " desfere uma série de golpes, energizados ao máximo no\n" 
                                           + " corpo do inimigo.");
                        inimigoDrg.hp -= 36 + 4;
                        break;
                    case 3:
                        System.out.println("Você se posiciona um passo para trás,\n" 
                                           + " estende uma única mão, cerrada, para frente,\n" 
                                           + " concentrando todo o seu KI.\n" 
                                           + " Se move em direção ao seu inimigo, pula, e\n" 
                                           + " desfere um poderoso soco no inimigo.n");
                        inimigoDrg.hp -= 21 +4;
                        break;
                    default:
                        System.out.println("Opção Inválida.");// caso digite outro numero
                        break;
                } if (inimigoDrg.hp> 0) {
                apareceTela("Dragão Ancião" + " Hp: " + inimigoDrg.hp  );
                apareceTela(jogador.nome + "\tHp: " + jogador.hp + "/" + jogador.maxHp);
                escAtaque = ataqueDrg();
                switch (escAtaque) {
                    case 1:
                        System.out.println("O Dragão Ancião te ingnora.\n");
                        
                        break;
                    case 2:
                        System.out.println("O Dragão Ancião continua te ingorando!\n");
                        break;
                    case 3:
                        System.out.println("O Dragão Ancião continua te ingorando!\n");
                        break;
                    case 4:
                        System.out.println("O Dragãoo Ancião cansa de olhar para você e\n" 
                                           + " ruge, soltando um breff, que te derrete." + " Você morreu!");
                        jogador.hp-= 400;
                        break;
                    default:
                        System.out.println("O Dragão Ancião tenta lhe acertar, mas você consegue se esquivar.");
                        break;
                }
            } else if (jogador.hp <= 0) {
                jogadorMorre();
                telaDesenha(1);
            } else {
                System.out.println("O Dragão Ancião cai morto"); // acabou a luta chama a aventura do jogo ou seja a historia
                  telaDesenha(1);
                }
            }
    }
        
   }

        
        
   
   static  void upGame(){
       if (jogador.xp > 0){
      if (jogador.xp >= 50 && jogador.xp <= 250){
       jogador.level = jogador.level + 1;
       jogador.maxHp = +150;
       System.out.println("Parabéns! Você subiu de nível(UP)!");
        escolheOpcao1();
  
      }else if (jogador.xp >= 251 && jogador.xp <= 450){
       jogador.level = jogador.level + 2;
        jogador.maxHp = + 200;
        System.out.println("Parabéns! Você subiu de nível(UP)!");
        escolheOpcao1();
                  
      }else if (jogador.xp >= 451 && jogador.xp <= 600){
       jogador.level = jogador.level + 3;
        jogador.maxHp = +250;
        System.out.println("Parabéns! Você subiu de nível(UP)!");
                  escolheOpcao1();
     }
   }else{
           
       }  
  }

   
   // !!!!!!!!!!!!!!!!!!! Ataques Persos !!!!!!!!!!!!
   
  public static int ataqueLadino() {
        Scanner at = new Scanner(System.in);
        System.out.println("Escolha o ataque: ");
        System.out.println("(1) - Flechada: " + "Causa 16 de Dano.");
        System.out.println("(2) - Corte com a adaga:" + " Causa 10 de Dano.");
        telaDesenha(1);
        return at.nextInt();
    }
  
    public static int ataqueLadino2() {
        Scanner at = new Scanner(System.in);
        System.out.println("Escolha o ataque: ");
        System.out.println("(1) - Flechada:" + " Causa 16 de Dano.");
        System.out.println("(2) - Corte com a adaga:" + " Causa 10 de Dano.");
        System.out.println("(3) - Tornado de Lâminas:" + " Causa 22 de Dano."); 
        telaDesenha(1);
        return at.nextInt();
    }
    
     public static int ataqueLadino3() {
        Scanner at = new Scanner(System.in);
        System.out.println("Escolha o ataque: ");
        System.out.println("(1) - Flechada:" + " Causa 16 de Dano.");
        System.out.println("(2) - Lâminas Envenenadas:" + " Causa 35 de Dano.");
        System.out.println("(3) - Tornado de Lâminas:" + " Causa 22 de Dano."); 
        telaDesenha(1);
        return at.nextInt();
    }
     
    public static int ataqueMago() {
        Scanner at = new Scanner(System.in);
        System.out.println("Escolha o ataque: ");
        System.out.println("(1) - Toque Chocante:" + " Causa 6 de Dano.");
        System.out.println("(2) - Toque Arrepiante:" + " Causa 13 de Dano.");
        telaDesenha(1);
        return at.nextInt();
    }
    
    public static int ataqueMago2() {
        Scanner at = new Scanner(System.in);
        System.out.println("Escolha o ataque: ");
        System.out.println("(1) - Toque Chocante:" + " Causa 6 de Dano.");
        System.out.println("(2) - Toque Arrepiante:" + " Causa 13 de Dano.");
        System.out.println("(3) - Chamas do Purgatório:" + "  Causa 21 de Dano.");
        telaDesenha(1);
        return at.nextInt();
    }
    
    public static int ataqueMago3() {
        Scanner at = new Scanner(System.in);
        System.out.println("Escolha o ataque: ");
        System.out.println("(1) - Meteoro:" + " Causa 45 de Dano.");
        System.out.println("(2) - Toque Arrepiante:" + " Causa 13 de Dano.");
        System.out.println("(3) - Chamas do Purgatório:" + "  causa 21 de Dano.");
        telaDesenha(1);
        return at.nextInt();
    }
    
    public static int ataqueMonge() {
        Scanner at = new Scanner(System.in);
        System.out.println("Escolha o ataque: ");
        System.out.println("(1) - Soco de Ki:" + " Causa 15 de Dano.");
        System.out.println("(2) - Chute Voadora:" + " Causa 8 de Dano.");
        telaDesenha(1);
        return at.nextInt();
    }
      
    public static int ataqueMonge2() {
        Scanner at = new Scanner(System.in);
        System.out.println("Escolha o ataque: ");
        System.out.println("(1) - Soco de Ki:" + " Causa 15 de Dano.");
        System.out.println("(2) - Chute Voadora:" + " Causa 8 de Dano.");
        System.out.println("(3) - Soco da Fé:" + " Causa 21 de dano.");
        telaDesenha(1);
        return at.nextInt();
    }
       
    public static int ataqueMonge3() {
        Scanner at = new Scanner(System.in);
        System.out.println("Escolha o ataque: ");
        System.out.println("(1) - Soco de Ki:" + " Causa 15 de Dano.");
        System.out.println("(2) - Ataques Consecutivos de Ki: " + " Causa 36 de Dano.");
        System.out.println("(3) - Soco da Fé: " + " Causa 23 de Dano.");
        telaDesenha(1);
        return at.nextInt();
    }
         
    // %%%%%%%%%%%%%%% Random ataque de inimigos %%%%%%%%%%%%%%%
    public static int ataqueMortoVivo() {
        Random porrada = new Random();
        return porrada.nextInt(3) + 1;
    }

    public static int ataqueAranhaGG() {
        Random porrada = new Random();
        return porrada.nextInt(3) + 1;
    }

    public static int ataqueAracnae() {
        Random porrada = new Random();
        return porrada.nextInt(3) + 1;
    }
    
     public static int ataqueLadrao() {
        Random porrada = new Random();
        return porrada.nextInt(3) + 1;
    }
     
   public static int ataqueMino() {
        Random porrada = new Random();
        return porrada.nextInt(3) + 1;
    }
   
   public static int ataqueDrg() {
        Random porrada = new Random();
        return porrada.nextInt(4) + 1;
    }
   
  // ::::::::::::::::::::::: Dead
   
 static void jogadorMorre(){
     telaDesenha(1);
     System.out.println(" Voce morreu!");
     System.out.println(" Obrigado por jogar");
     estaRodando = false; // chamar fim de jogo 
      
 }
  
   
}