package com.mycompany.rpgs;

import static com.mycompany.rpgs.Game.digitaAlgo;
import static com.mycompany.rpgs.Game.escolheOpcao1;
import static com.mycompany.rpgs.Game.iniciaIntro;
import static com.mycompany.rpgs.Game.iniciaIntro2;
import static com.mycompany.rpgs.Game.iniciaIntro3;
import static com.mycompany.rpgs.Game.jogador;
import static com.mycompany.rpgs.Game.limpaTudo;
import static com.mycompany.rpgs.Game.sleep;
import static com.mycompany.rpgs.Game.telaDesenha;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
// ser� que � por causa disso?
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author rodrigo
 */

public class Historias {
    
    
     public static void introLadino() throws Exception {
         
         Path arquivo = Paths.get("C:/Users/Backup/Desktop/ProjetoAP2/src/test/java/tex1.txt");
         
         List<String> linhas = Files.readAllLines(arquivo);
                 
         for(String linha:linhas){
             System.out.println(linha);
         }
        Game.telaDesenha(1);
        Game.digitaAlgo();
        Game.iniciaIntro();
        
         
    }
    public static void introMonge()throws Exception {
       
      Game.escolheOpcao1();
        Path arquivo = Paths.get("C:/Users/Backup/Desktop/ProjetoAP2/src/test/java/tex2.txt");
                
         List<String> linhas = Files.readAllLines(arquivo);
                 
         for(String linha:linhas){
             System.out.println(linha);
         }
        Game.telaDesenha(1);
         Game.digitaAlgo();
      Game.iniciaIntro3();
        
    }
    public static void introNecro() throws Exception {

     Game.escolheOpcao1();
        Path arquivo = Paths.get("C:/Users/Backup/Desktop/ProjetoAP2/src/test/java/tex3.txt");
                
         List<String> linhas = Files.readAllLines(arquivo);
                 
         for(String linha:linhas){
             System.out.println(linha);
         }
    
        Game.telaDesenha(1);
         Game.digitaAlgo();
         Game.iniciaIntro2();
    }
       public static void apareceIntroduçaoLadino() throws Exception {
       Game.escolheOpcao1(); 
       Game.telaDesenha(1); 
       
            Path arquivo = Paths.get("C:/Users/Backup/Desktop/ProjetoAP2/src/test/java/intro1.txt");
                       
         List<String> linhas = Files.readAllLines(arquivo);
                 
         for(String linha:linhas){
             System.out.println(linha);
         }
         Game.digitaAlgo();

    }   
    
    public static void apareceIntroduçaoMonge()throws Exception {
        Game.limpaTudo();
        Game.telaDesenha(1);
        
        Path arquivo = Paths.get("C:/Users/Backup/Desktop/ProjetoAP2/src/test/java/intro2.txt");
                       
         List<String> linhas = Files.readAllLines(arquivo);
                 
         for(String linha:linhas){
             System.out.println(linha);
         }
         Game.digitaAlgo();

    }    
    
  public static void apareceIntroduçaoNecro()throws Exception {
        Game.limpaTudo();
        Game.telaDesenha(1);
        
        Path arquivo = Paths.get("C:/Users/Backup/Desktop/ProjetoAP2/src/test/java/intro3.txt");
                       
         List<String> linhas = Files.readAllLines(arquivo);
                 
         for(String linha:linhas){
             System.out.println(linha);
         }
         Game.digitaAlgo();
  }
   
     // come�a quando estamos no portao 
    public static void apareceHistoria1()throws Exception{
        Game.limpaTudo();
        Game.telaDesenha(1);
        
        Path arquivo = Paths.get("C:/Users/Backup/Desktop/ProjetoAP2/src/test/java/apareceHistoria1.txt");
                       
         List<String> linhas = Files.readAllLines(arquivo);
                 
         for(String linha:linhas){
             System.out.println(linha);
         }
        Game.digitaAlgo();
    }
    public static void irEstrada()throws Exception{
        Game.limpaTudo();
        Game.telaDesenha(1);
  
        Path arquivo = Paths.get("C:/Users/Backup/Desktop/ProjetoAP2/src/test/java/irEstrada.txt");
                       
         List<String> linhas = Files.readAllLines(arquivo);
                 
         for(String linha:linhas){
             System.out.println(linha);
         }
        Game.telaDesenha(1);
        Game.digitaAlgo();
    }
  public  static void ficarEnfrentar()throws Exception{
     Game.limpaTudo();
     Game.telaDesenha(1);
     
      Path arquivo = Paths.get("C:/Users/Backup/Desktop/ProjetoAP2/src/test/java/ficarEnfrentar.txt");
                       
         List<String> linhas = Files.readAllLines(arquivo);
                 
         for(String linha:linhas){
             System.out.println(linha);
         }
        Game.telaDesenha(1);
        Game.digitaAlgo();
    }
    
    
 public   static void continuaFloresta()throws Exception{
       Game.limpaTudo();
        Game.telaDesenha(1);
        Game.sleep
        ();
        
      Path arquivo = Paths.get("C:/Users/Backup/Desktop/ProjetoAP2/src/test/java/continuaFloresta.txt");
                       
         List<String> linhas = Files.readAllLines(arquivo);
                 
         for(String linha:linhas){
             System.out.println(linha);
         }
        Game.telaDesenha(2);
        Game.digitaAlgo();
    }
  public  static void voltaFloresta()throws Exception{
         Game.limpaTudo();
        Game.telaDesenha(1);
        
      Path arquivo = Paths.get("C:/Users/Backup/Desktop/ProjetoAP2/src/test/java/voltaFloresta.txt");
                       
         List<String> linhas = Files.readAllLines(arquivo);
                 
         for(String linha:linhas){
             System.out.println(linha);
         }
        Game.telaDesenha(2);
        Game.digitaAlgo();
    }
  public  static void ficareVer()throws Exception{
       Game.limpaTudo();
        Game.telaDesenha(1);
        
      Path arquivo = Paths.get("C:/Users/Backup/Desktop/ProjetoAP2/src/test/java/ficareVer.txt");
                       
         List<String> linhas = Files.readAllLines(arquivo);
                 
         for(String linha:linhas){
             System.out.println(linha);
         }
        Game.telaDesenha(2);
        Game.digitaAlgo();
    }
  public  static void aprocCadaver()throws Exception{
         Game.limpaTudo();
        Game.telaDesenha(1);
        
      Path arquivo = Paths.get("C:/Users/Backup/Desktop/ProjetoAP2/src/test/java/aprocCadaver.txt");
                       
         List<String> linhas = Files.readAllLines(arquivo);
                 
         for(String linha:linhas){
             System.out.println(linha);
         }
        Game.telaDesenha(2);
        Game.digitaAlgo();
    }
  public  static void depoisdaBatalha01()throws Exception{
       Game.limpaTudo();
        Game.telaDesenha(1);
        
      Path arquivo = Paths.get("C:/Users/Backup/Desktop/ProjetoAP2/src/test/java/depoisdaBatalha01.txt");
                       
         List<String> linhas = Files.readAllLines(arquivo);
                 
         for(String linha:linhas){
             System.out.println(linha);
         }
        Game.telaDesenha(1);
        Game.digitaAlgo();
}
   public static void estradadoCastelo()throws Exception{
     Game.limpaTudo();
        Game.telaDesenha(1);
        
      Path arquivo = Paths.get("C:/Users/Backup/Desktop/ProjetoAP2/src/test/java/estradadoCastelo.txt");
                       
         List<String> linhas = Files.readAllLines(arquivo);
                 
         for(String linha:linhas){
             System.out.println(linha);
         }
        Game.telaDesenha(1);
        Game.digitaAlgo();
    }
  
  public  static void apareceHistora2()throws Exception{
       Game.limpaTudo();
        Game.telaDesenha(1);
   
        Path arquivo = Paths.get("C:/Users/Backup/Desktop/ProjetoAP2/src/test/java/apareceHistoria2.txt");
                       
         List<String> linhas = Files.readAllLines(arquivo);
                 
         for(String linha:linhas){
             System.out.println(linha);
         }
        Game.telaDesenha(1);
        Game.digitaAlgo();
    }
 public   static void apareceArcnae()throws Exception{
        Game.limpaTudo();
        Game.telaDesenha(1);
        
      Path arquivo = Paths.get("C:/Users/Backup/Desktop/ProjetoAP2/src/test/java/apareceArcnae.txt");
                       
         List<String> linhas = Files.readAllLines(arquivo);
                 
         for(String linha:linhas){
             System.out.println(linha);
         }
        
        Game.telaDesenha(1);
        Game.digitaAlgo(); 
    }
     
  public static void CidadeRust()throws Exception {
        Game.limpaTudo();
        Game.telaDesenha(1);
        
      Path arquivo = Paths.get("C:/Users/Backup/Desktop/ProjetoAP2/src/test/java/CidadeRust.txt");
                       
         List<String> linhas = Files.readAllLines(arquivo);
                 
         for(String linha:linhas){
             System.out.println(linha);
         }
        Game.digitaAlgo();
    }
   
  public static void EstradaTerra()throws Exception {
        Game.limpaTudo();
        Game.telaDesenha(1);
        
      Path arquivo = Paths.get("C:/Users/Backup/Desktop/ProjetoAP2/src/test/java/EstradaTerra.txt");
                       
         List<String> linhas = Files.readAllLines(arquivo);
                 
         for(String linha:linhas){
             System.out.println(linha);
         }
        Game.digitaAlgo();
    }    
    
   public     static void CabanaAbandonada()throws Exception {
        Game.limpaTudo();
        Game.telaDesenha(1);
        
       Path arquivo = Paths.get("C:/Users/Backup/Desktop/ProjetoAP2/src/test/java/CabanaAbandonada.txt");
                       
         List<String> linhas = Files.readAllLines(arquivo);
                 
         for(String linha:linhas){
             System.out.println(linha);
         }
        Game.digitaAlgo();
    }       
   public  static void Ponte()throws Exception {
        Game.limpaTudo();
        Game.telaDesenha(1);
        
      Path arquivo = Paths.get("C:/Users/Backup/Desktop/ProjetoAP2/src/test/java/Ponte.txt");
                       
         List<String> linhas = Files.readAllLines(arquivo);
                 
         for(String linha:linhas){
             System.out.println(linha);
         }
        Game.digitaAlgo();
    }     
   public  static void TavernaWineFord()throws Exception {
        Game.limpaTudo();
        Game.telaDesenha(1);
        
       Path arquivo = Paths.get("C:/Users/Backup/Desktop/ProjetoAP2/src/test/java/TavernaWineFord.txt");
                       
         List<String> linhas = Files.readAllLines(arquivo);
                 
         for(String linha:linhas){
             System.out.println(linha);
         }
        Game.telaDesenha(1);
        Game.digitaAlgo();
    }     
 public   static void LoudWater()throws Exception {
        Game.limpaTudo();
        Game.telaDesenha(1);
        
       Path arquivo = Paths.get("C:/Users/Backup/Desktop/ProjetoAP2/src/test/java/LoudWater.txt");
                       
         List<String> linhas = Files.readAllLines(arquivo);
                 
         for(String linha:linhas){
             System.out.println(linha);
         }
    }  
  public  static void LoudWater2()throws Exception {
        Game.limpaTudo();
        Game.telaDesenha(1);
        
       Path arquivo = Paths.get("C:/Users/Backup/Desktop/ProjetoAP2/src/test/java/LoudWater2.txt");
                       
         List<String> linhas = Files.readAllLines(arquivo);
                 
         for(String linha:linhas){
             System.out.println(linha);
         }
        Game.digitaAlgo();
    }     
  public  static void Final()throws Exception {
        Game.limpaTudo();
        Game.telaDesenha(1);
        
       Path arquivo = Paths.get("C:/Users/Backup/Desktop/ProjetoAP2/src/test/java/Final.txt");
                       
         List<String> linhas = Files.readAllLines(arquivo);
                 
         for(String linha:linhas){
             System.out.println(linha);
         }
        Game.telaDesenha(1);
        Game.digitaAlgo();
    }          
   
    
   
 }
    
    


