package com.mycompany.rpgs;


import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author rodrigo
 */
public class Player extends Personagens{
    //armazena o numero das atualizaçoes das habilidades
    public int numAtkMago,numAtkMonge, numAtkLadino;   
    int pots, xp, level,raça,cla;
    
    
    // matriz esta armazenando nome das habilidades
  
     public static String[] Mago = {"NECROMANTE", "Chamas do Purgatório", "Meteoro"};
    public static String[] Ladino = {"LADINO", "Tornado de Lâminas", "Lâminas envenenadas "};
    public static String[] Monge = {"MONGE", "Soco da Fé","Ataques consecutivos de Ki"};
    
    //construtor do jogador
    public Player(String nome) throws Exception{
        // constrotr da superclasse
        super(nome, 100, 0, 0,0,0);
        //configura as atualizaçoes
        this.numAtkMago = 0; 
        this.numAtkMonge = 0;
        this.numAtkLadino = 0;
        this.pots = 1;
        this.raça = 0;
        this.cla = 0;
       
    }
    
     
    

   
}
