package com.mycompany.rpgs;

import static com.mycompany.rpgs.Game.digitaAlgo;
import static com.mycompany.rpgs.Game.escolheOpcao1;
import static com.mycompany.rpgs.Game.iniciaIntro;
import static com.mycompany.rpgs.Game.iniciaIntro2;
import static com.mycompany.rpgs.Game.iniciaIntro3;
import static com.mycompany.rpgs.Game.jogador;
import static com.mycompany.rpgs.Game.limpaTudo;
import static com.mycompany.rpgs.Game.sleep
        ;
import static com.mycompany.rpgs.Game.telaDesenha;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author rodrigo
 */
public class Historias {
    
     public static void introLadino() throws Exception {
    
       
        System.out.println("Introdução Ladino");
        Game.telaDesenha(1);
        System.out.println(" Órfão desde os dez anos, você foi criado nas ruas de uma cidade portuária\n" 
                           + " chamada Delfos. Logo teve que aprender a furtar bolsos e arrancar bolsas\n" 
                           + " de senhoras e senhores para comer e sobreviver.\n" 
                           + " Certo dia, ao avistar um homem, com uma grande saca de moedas pendurada em\n" 
                           + " sua cintura. E então, logo pensa, que com aquela quantidade de moedas finalmente\n" 
                           + " poderia comprar aquele punhal curvo enfeitado por lindas pedras que viu em uma\n" 
                           + " armaria.\n" 
                           + " Sem pestanejar por mais nenhum segundo, você aproximou-se do homem e, em um\n" 
                           + " movimento seco e rápido, arrancou a bolsa de ouro e pôs-se a correr.\n"
                           + " Entrou num beco e sentou para contar seu lucro, quando percebeu que uma sombra o\n" 
                           + " cobria, era o dono do dinheiro. O homem olhou para você, esboçou um leve sorriso\n" 
                           + " e disse: \n" 
                           + " ”Por DEUS, HAHAHA!! Acreditava que não poderia ser furtado por ninguém. Vejo que\n"
                           + " estava enganado. Você, menino, possui um grande talento. Eu o levarei para a minha\n" 
                           + " guilda, e o ensinarei a arte de roubar e enganar os outros”.");
//        System.out.println("\n Caracteristicas -->" + "1. Mestre da furtividade.\n "
//                    + "\n 2. Mestre do assassinato.\n "
//                    + "\n 3. Otimo ladrão.\n "
//                    + "\n 4. Bom de papo.\n ");
        Game.telaDesenha(1);
         Game.digitaAlgo();
       Game.iniciaIntro();
    }
    public static void introMonge() {
       
      Game.escolheOpcao1();
        System.out.println("Introdução Monge");
        Game.telaDesenha(1);
        System.out.println("Os deuses estão em todas as coisas, e por toda parte.\n" 
                           + "Quando você ainda era um bebê te largaram na frente de um enorme monasterio.\n" 
                           + "Os monges que lá moravam te acolheram. E por anos te deram comida para sua fome,\n" 
                           + "abrigo para o frio e o lhe mostraram o caminhos dos punhos espirituais.\n" 
                           + "Tudo estava em perfeita armonia até que o GRÃO-mestre revela uma professia que logo\n" 
                           + "iria se profetizar.\n" 
                           + "Profecia: Logo, fogo incendeiará os céus, calcinando a abóbada celeste...E um de\n" 
                           + "vocês terá que cumprir a vontade dos patriarcas.\n"  
                           + "Seu povo fica inquieto...\n" 
                           + "Então vendo aquilo você se oferece para combater o mal que estavá por vir.\n" 
                           + "O GRÃO-mestre aceita a proposta e diz que vai lhe encinar um estilo de luta que\n"
                           + "ajudará em sua jornada.\n" 
                           + "Apartir dali começa o seu àrduo treinamento para deter o mal.\n");
//        System.out.println("Caracteristicas -->" + " 1. Mestre da luta corpo a corpo.\n "
//                    + " 2. Mestre em luta espiritual.\n "
//                    + " 3. Otimo defensor.\n "
//                    + " 4. Baixo carisma.\n");
        Game.telaDesenha(1);
         Game.digitaAlgo();
      Game.iniciaIntro3();
    }
    public static void introNecro() throws Exception {

     Game.escolheOpcao1();
        System.out.println("Introdução Necromante");
        Game.telaDesenha(1);
       System.out.println("Você era um jovem aprendiz de magia muito promissor, filho de dois grandes magos,\n" 
                           + "porém sua infância era um tanto quanto solitária, seus pais viajam por longos\n" 
                           + "períodos de tempo em missões, eles sempre estavam ocupados e não te davam a devida\n" 
                           + "atenção.\n" 
                           + "Até um dia em que um grande grifo, uma linda nobre ave, te entrega uma carta e se\n" 
                           + "curva, quando você abre a carta recebe a notícias que ambos seus pais foram mortos\n" 
                           + "por um minotauro em um calabouço, porém aquilo te traz uma dúvida gigantesca,\n" 
                           + "nenhuma criatura era párea para eles.\n" 
                           + "Um certo dia, você se frustrou, começou a fazer serviços de mercenário.\n"
                           + "Era um bom dinheiro, porém você se perdeu, após anos em uma taverna, você\n"  
                           + "estava se embebedando quando uma velha senhora de aparencia amigável fala pra você:\n" 
                           + "Eu tenho as respostas que você precisa... hihhihihihih!!!\n" 
                           + "E você perguntou rapidamente:\n" 
                           + "VOCÊ SABE ALGO SOBRE MEUS PAIS?\n" 
                           + "Ao perceber o seu desespero a velha te ofereçe uma proposta\n" 
                           + "Você pode descobrir tudo, mas por um preço alto\n" 
                           + "E você responde:\n" 
                           + "Dinheiro não é um problema, diga, quanto você quer?\n" 
                           + "Ela te entrega um livro macabro e sai rindo da taverna.\n" 
                           + "Quando você abre o livro descobre que se trata de magia de sangue, uma magia\n" 
                           + "que foi proibida, conversas com os mortos, porém pagando um preço alto, após\n"
                           + "executar um ritual para ter uma visão sobre o momento da morte de seus pais, você\n" 
                           + "escuta eles falarem sobre como não querem voltar para casa e que a criança é um\n" 
                           + "empecilho para suas viagens, logo após isso um demônio gigante esmaga os dois, porém\n" 
                           + "uma vez que a magia de sangue é usada, você começa a ouvir vozes por onde passa\n" 
                           + "e consegue ver os espíritos que rodeiam seu cômodo, rapidamente...\n" 
                           + "Você enlouquece e se isola da sociedade.");

        Game.telaDesenha(1);
         Game.digitaAlgo();
         Game.iniciaIntro2();
    }
       public static void apareceIntroduçaoLadino() throws Exception {
   
          Game.escolheOpcao1();      
        System.out.println("Introdução");
        Game.telaDesenha(1);
        
         System.out.println("Narrador:" + "\nUm meteoro surge iluminando a noite, ao cair ele destrói\n" 
                           + "uma região inteira “kabummm”, causando um grande estrondo e destruição,\n"
                           + "que acabou acordando um antigo dragão tão negro quanto a noite, das suas asas\n" 
                           + "rasgadas rodeadas por fumaça, seus olhos são cinzas como se não tivesse\n" 
                           + "vida, sua raiva foi tão grande que ao levantar ele rugi “raaawww”,\n" 
                           + "seu rugido faz com q os mortos comecem a levantar, o dragão então\n" 
                           + "começa a  voar destruindo tudo em seu caminho, até que ele chega\n" 
                           + "no reino de LoudWater, e pousa dentro do reino, destruindo tudo a\n" 
                           + "sua volta. Todos, que ali estavam, começaram a gritar e correr,\n" 
                           + "o dragão, ainda furioso, bate suas asas “fuuu” “fuuu”\n" 
                           + "indo para cima e de sua garganta só se escutava o son “thrummm” e\n" 
                           + "então de sua boca, ele solta um breef na cor petra, que queima tudo a sua frente.\n" 
                 
                            +"— Algumas semanas depois —\n" 
                            + "— No Reino de Fal—\n" 
                            + "— O Rei Baldor o convocou para uma audiência.\n" 
         
                             +"Baldor - Sabe o porque eu te chamei aqui?\n" + 
         
         jogador.nome + " - imagino, mas não quero saber o motivo, só quanto\n" 
                          + "ganharei em troca do serviço.\n" +
          
                 "Baldor - Eu te chamei aqui porque sei que você tem a habilidade\n" 
                             + "que nenhum outro tem, e pode ficar tranquilo quanto ao pagamento,\n" 
                             + "ele será bem generoso.\n"+ 
         
                 jogador.nome + " - Já que não preciso me preocupar com o pagamento,\n" 
                           + "pode contar comigo Baldor, eu não falharei nessa missão, o alvo nem saberá\n"
                           + "de onde veio o ataque.\n"+
         
         "Baldor - HAHA! Certo, vou lhe enviar uma carta, com algumas instruções que irão\n" 
                            + "te ajudar nessa aventura.\n" +

         
        " - CARTA RECEBIDA - \n" +
        
         "Não sei se você está sabendo, mas um dragão veio até a nossa querida cidade de\n" 
                            + "Loudwater e acabou destruindo tudo. Quero que você o encontre e mate ele para\n" 
                            + "mim. Eu te escolhi, pois acredito que você tem as habilidades necessárias para\n" 
                            + "essa missão, ouvi dizer que voce é um mestre da furtividade e da fuga além de ser\n" 
                            + "um grande assassino.\n" 
                            + "Lembre-se que sua jornada estará repleta de inimigos perigosos e terá que tomar\n" 
                            + "muito cuidado. E não se esqueça, preste bem atenção por onde anda, você poderá\n" 
                            + "encontrar alguns itens na estrada que irão te ajudar.\n" +
        
        " CONTRATO ACEITO COM SUCESSO!");
         Game.digitaAlgo();

    }   
    
    public static void apareceIntroduçaoMonge() {
        Game.limpaTudo();
        Game.telaDesenha(1);
        System.out.println("Introduçao");
        Game.telaDesenha(1);
        Game.sleep
        (); 
        System.out.println("Narrador:" + "\nUm meteoro surge iluminando a noite, ao cair ele destrói\n" 
                           + "uma região inteira “kabummm”, causando um grande estrondo e destruição,\n"
                           + "que acabou acordando um antigo dragão tão negro quanto a noite, das suas asas\n" 
                           + "rasgadas rodeadas por fumaça, seus olhos são cinzas como se não tivesse\n" 
                           + "vida, sua raiva foi tão grande que ao levantar ele rugi “raaawww”,\n" 
                           + "seu rugido faz com q os mortos comecem a levantar, o dragão então\n" 
                           + "começa a  voar destruindo tudo em seu caminho, até que ele chega\n" 
                           + "no reino de LoudWater, e pousa dentro do reino, destruindo tudo a\n" 
                           + "sua volta. Todos, que ali estavam, começaram a gritar e correr,\n" 
                           + "o dragão, ainda furioso, bate suas asas “fuuu” “fuuu”\n" 
                           + "indo para cima e de sua garganta só se escutava o son “thrummm” e\n" 
                           + "então de sua boca, ele solta um breef na cor petra, que queima tudo a sua frente.\n");
         Game.telaDesenha(1);
         Game.digitaAlgo();
        Game.sleep
        ();
         System.out.println("— Algumas semanas depois —\n" 
                            + "— No Reino de Fal—\n" 
                            + "— O Rei Baldor o convocou para uma audiência.\n");
         Game.sleep
        ();
         System.out.println("Baldor - Bom dia! Meu caro cristão.\n");
         Game.sleep
        ();
         System.out.println(jogador.nome + " - Bom dia, meu caro andarilho.\n");
         Game.sleep
        ();
         System.out.println("Baldor - O senhor sabe o porquê eu vim até esse monastério ?\n");
         Game.sleep
        ();
         System.out.println (jogador.nome + " - Sei sim, meu caro Senhor.\n");
         Game.sleep
        ();
         System.out.println(" Baldor - Sabe mesmo?\n");
         Game.sleep
        ();
         System.out.println(jogador.nome + " - Sim! O senhor veio procurar as graças do senhor, não é?\n");
         Game.sleep
        ();
         System.out.println(" Baldor - HAHA! Não mesmo meu amigo! Vim aqui, até esse monastério para\n"  
                            + "te pedir ajuda. Ouvi boatos, que em um monastério, no alto de uma montanha,\n" 
                            + "existia, um homem, que era imbatível com seus punhos.\n" 
                            + "Então, rapidamente vim falar com o ancião daqui, e ele informou que\n"
                            + "quem eu procuro estaria no pico da montanha meditando.\n"); 
         Game.sleep
        ();
         System.out.println(jogador.nome+ " - Sim, infelizmente sou eu, mas eu já não faço mais parte dessa vida, já faz\n" 
                            + "um longo tempo.\n" 
                            +"Agora só uso minhas mãos para rezar.\n");
         Game.sleep
        ();
         System.out.println(" Baldor - Sinto lhe dizer, meu amigo, que você terá que usar novamente seus punhos,\n" 
                   + "pois tenho uma tarefa muito importante para você!!!.\n" 
                   + "Um dragão atacou uma cidade bem próxima daqui, muitas pessoas morreram e o monastério\n" 
                   + "será o próximo, se você não detê-lo. Portanto, e seu dever protetegê-lo\n" 
                   + "A missão é essa, encontre o dragão e o mate, fique tranquilo você receberá uma recompensa\n" 
                   + " pela sua ajuda.\n"); 
         Game.sleep
        ();
         System.out.println (jogador.nome + " - Bom nesse caso não tenho escolhas, não posso ficar aqui parado vendo\n" 
                             + "pessoas morrerem. Eu irei te ajudar com a graça que me foi concedida pelo senhor.\n"
                             + "Não se preocupe, jamais falharei nessa missão\n");  
        Game.sleep
        ();
         System.out.println(" MISSÃO RELIGIOSA ACEITA COM SUCESSO!");
         Game.digitaAlgo();

    }    
    
  public static void apareceIntroduçaoNecro() {
        Game.limpaTudo();
        Game.telaDesenha(1);
        System.out.println("Introduçao");
        Game.telaDesenha(1);
        Game.sleep
        ();
         System.out.println("Narrador:" + "\nUm meteoro surge iluminando a noite, ao cair ele destrói\n" 
                           + "uma região inteira “kabummm”, causando um grande estrondo e destruição,\n"
                           + " que acabou acordando um antigo dragão tão negro quanto a noite, das suas asas\n" 
                           + "rasgadas rodeadas por fumaça, seus olhos são cinzas como se não tivesse\n" 
                           + "vida, sua raiva foi tão grande que ao levantar ele rugi “raaawww”,\n" 
                           + "seu rugido faz com q os mortos comecem a levantar, o dragão então\n" 
                           + "começa a  voar destruindo tudo em seu caminho, até que ele chega\n" 
                           + "no reino de LoudWater, e pousa dentro do reino, destruindo tudo a\n" 
                           + "sua volta. Todos, que ali estavam, começaram a gritar e correr,\n" 
                           + "o dragão, ainda furioso, bate suas asas “fuuu” “fuuu”\n" 
                           + "indo para cima e de sua garganta só se escutava o son “thrummm” e\n" 
                           + "então de sua boca, ele solta um breef na cor petra, que queima tudo a sua frente.\n");
         Game.telaDesenha(1);
         Game.digitaAlgo();
         Game.sleep
        ();
         System.out.println("— Algumas semanas depois —\n" 
                            + "— No Reino de Fal—\n" 
                            + "— O Rei Baldor o convocou para uma audiência.\n");
         Game.sleep
        ();
         System.out.println("Baldor - Sabe o porque eu te chamei aqui?\n"); 
         Game.sleep
        ();
         
         System.out.println(jogador.nome + " - Eu não sei, porém deve ter sido um bom motivo para me tirar de meu covil.\n");
         Game.sleep
        ();
         System.out.println(" Baldor - Necromante, você é o responsável por todo esse caos? Suas criaturas nefastas\n"                            + "tomaram conta do reino e você pagará por coloca-lás em nosso território.\n"); 
         Game.sleep
        ();
         System.out.println (jogador.nome + " - Não Senhor! eu não estou envolvido, inclusive interrompeu meu descanso,\n" 
                             + "porém com meus poderes, eu certamente poderei ajudar o senhor com esses impecilhos\n" 
                             + "mal invocados.\n");
         Game.sleep
        ();
         System.out.println("Baldor - Certo certo! Eu acredito em você, vou lhe enviar uma carta com algumas\n" 
                            + "instruções que irão te ajudar na sua aventura. Faremos um pacto, se o serviço for\n" 
                            + "concluído não te incomodarei mais em seus descansos funebres.\n");
         System.out.println(" - CARTA RECEBIDA - \n");
         System.out.println("Não sei se você está sabendo, mas um dragão veio até a nossa querida cidade de\n" 
                            + "Loudwater e acabou destruindo tudo. Quero que você o encontre e mate ele para\n" 
                            + "mim. Eu te escolhi, pois acredito que você tem as habilidades necessárias para\n" 
                            + "essa missão, ouvi dizer que voce é um mestre das sombras e que conhece bem sobre\n" 
                            +  "os mortos-vivos. Um verdadeiro mestre da magia de sangue.\n"  
                            + "Lembre-se que sua jornada estará repleta de inimigos perigosos e terá que tomar\n" 
                            + "muito cuidado. E não se esqueça, preste bem atenção por onde anda, você poderá\n" 
                            + "encontrar alguns itens na estrada que irão te ajudar.\n");     
    
         System.out.println(" PACTO ACEITO COM SUCESSO!.");
         Game.digitaAlgo();
  }
   
     // começa quando estamos no portao 
    static void apareceHistoria1(){
        Game.limpaTudo();
        Game.telaDesenha(1);
        System.out.println(" Portão do castelo ");
    
        Game.telaDesenha(1);
        System.out.println("Baldor: Como você ja foi informado sobre o  ocorrido ao norte daqui.\n" 
                           + "Eu o chamei porque preciso de ajuda temos uma aliança com  o reino de\n" 
                           + "LoudWater a anos  e precisamos ter certeza do que aconteceu e se alguem\n" 
                           + "da familia real ainda esta viva.");
        Game.telaDesenha(1);
      
        System.out.println("Baldor: Por isso estou mandando você para averiguar e ajudar o rei Razor caso\n" 
                           + "seja necessário.");
     
        System.out.println("Narrador: Ao fundo sons de sinos tocam , o sinal de invasão.  Enquanto isso no\n" 
                           + "grande salão , um guarda aparece correndo e gritando.");
      
        System.out.println("Guarda: Meu rei, meu rei (o guarda se ajoelha ainda ofegante) estamos sendo atacados,\n"
                           + "há um grupo enorme de mortos vivos no portao do norte do reino, o que devemos fazer? ");
     
        System.out.println("Baldor gritando: Mobilizem todos os soldados, hoje mataremos os mortos.");
     
        System.out.println("Baldor: Venha conosco esses monstros provavelmente vieram da direção do reino de\n" 
                           + "LoudWater.");
     
        Game.telaDesenha(1);
        System.out.println("Cenário Portão Norte : Corpos de cadáveres destruídos, alguns guardas feridos,\n" 
                           + "atrás de você há um portao enorme que está aberto com tropas de guardas saindo\n" 
                           + "com alguns javalis juntos ao seu lado esta o proprio rei montado em um javali\n" 
                           + "enorme e na sua frente algo inexplicável uma horda enorme de mortos vivos desde\n" 
                           + "pessoas normais ate monstros.");
    
        System.out.println("Baldor gritando: “homens hoje defenderemos nosso reino nossas casas e nossas familias”.");
   
        System.out.println("Narrador:  então todos partem para cima dos mortos.");
        Game.digitaAlgo();
    }
    static void irEstrada(){
        Game.limpaTudo();
        Game.telaDesenha(1);
        System.out.println(" Narrador: Você deixa o javali para trás e continua andando até a direção da estrada,\n" 
                           + "assim que você sai da floresta você vê mais claramente a  carruagem destruída.");
        Game.telaDesenha(1);
       
        System.out.println("Cenário Estrada: Já está anoitecendo há uma carruagem que foi destruída no meio\n" 
                           + "há sua frente, vc sente um cheiro forte de cadáver, na frente de uma das partes\n" 
                           + "da carruagem  você vê um cavalo morto, na porta da carruagem tem o que parece\n" 
                           + "ser metade de um corpo a outro corpo jogado no outro lado.");
        Game.telaDesenha(1);
        Game.digitaAlgo();
    }
    static void ficarEnfrentar(){
     Game.limpaTudo();
        
        Game.telaDesenha(1);
       
        System.out.println(" Narrador: Você se prepara para enfrentar o que estiver vindo na sua direção,\n" 
                           + "quando mais perto chega mais o chão treme e então do nada  para, vc olha em\n" 
                           + "volta assustado  mais não vi nada diferente, até que o chão começa a tremer\n" 
                           + "como um terremoto muito mais forte que os outros e do seu pé surge um verme\n" 
                           + "gigante, ele o engole de uma vez junto com a própria terra, lhe esmagando\n" 
                           + "e o triturando com seus dentes.");
        Game.telaDesenha(2);
        System.out.println("Você se Matou!");
        Game.telaDesenha(1);
        Game.digitaAlgo();
    }
    
    
    static void continuaFloresta(){
       Game.limpaTudo();
        Game.telaDesenha(1);
        Game.sleep
        ();
        System.out.println(" Narrador: Você continua andando pela floresta , um pouco depois começa a ter\n" 
                           + "a sensação de que está sendo observado, e acha ainda mais estranho pois ainda\n" 
                           + "não escutou ou viu nenhum tipo de bicho selvagem, começa a anoitecer e nada \n" 
                           + "aconteceu, mas conforme você andou percebeu q a floresta a sua volta estava estranha.");
        Game.telaDesenha(2);
        Game.digitaAlgo();
    }
    static void voltaFloresta(){
         Game.limpaTudo();
        
        Game.telaDesenha(1);
        
        System.out.println("Narrador: Você rapidamente corre de volta para a floresta, correndo tão rápido,\n" 
                           + "que depois de um tempo vc percebe q nao sente mais nenhum tremor na terra,\n" 
                           + "infelizmente já estava de noite e você não percebeu direito por onde estava indo.");
        Game.telaDesenha(2);
        Game.digitaAlgo();
    }
    static void ficareVer(){
       Game.limpaTudo();
        Game.telaDesenha(1);
        System.out.println("Narrador:De repente você escuta um trotar de cavalo e sente a terra tremendo ao\n" 
                           + "fundo um barulho de árvores caindo, o cavalo sai da floresta correndo passando\n" 
                           + "por você, logo atrás dele você vê o chão se movendo como se tivesse vida própria\n" 
                           + "vindo na sua direção.");
        Game.telaDesenha(2);
        Game.digitaAlgo();
    }
    static void aprocCadaver(){
         Game.limpaTudo();
        Game.telaDesenha(1);
        System.out.println("Narrador: De repente você escuta um trotar de cavalo e sente a terra tremendo\n" 
                           + "ao fundo um barulho de árvores caindo, o cavalo sai da floresta correndo\n" 
                           + "passando por você, logo atrás dele você vê o chão se movendo como se tivesse\n"
                           +" vida própria vindo na sua direção.");
        Game.telaDesenha(2);
        Game.digitaAlgo();
    }
    static void depoisdaBatalha01(){
       Game.limpaTudo();
        Game.telaDesenha(1);
        System.out.println("Baldor: Você deve ir a diante, ha muitos deles, você deve cumprir sua missão.");
        System.out.println("Narrador: Então você parte correndo pela floresta montado em uns dos javalis. ");
        Game.telaDesenha(2);
        System.out.println("Narrador: Algumas horas depois ja estava longe  do reino de fal, você ainda não tinha\n" 
                           + " saido da floresta, o javali parou ele estava muito cansado.");
        System.out.println("Cenario Floresta: Árvores enormes por todos os lados, o sol esta se pondo,\n" 
                           + "não havia sons de animais selvagens e nem sons estranhos, a esquerda muito\n" 
                           + "há frente você consegue ver algo parecido com uma carruagem que esta na estrada. ");
        Game.telaDesenha(1);
        Game.digitaAlgo();
}
    static void estradadoCastelo(){
     Game.limpaTudo();
        Game.telaDesenha(1);
        System.out.println(" Na Estrada: ");
        Game.telaDesenha(2);
        System.out.println("Narrador: Você deixa o javali para tras e continua andando até a direção da\n" 
                           + "estrada, assim que você sai da floresta você vê mais claramente a carruagem\n" 
                           + "destruída.");
        Game.telaDesenha(1);
        Game.digitaAlgo();
    }
  
    static void apareceHistora2(){
       Game.limpaTudo();
        Game.telaDesenha(1);
        System.out.println(" Narrador: Você para e começa a reparar na floresta, decide acender uma tocha\n" 
                           + "para melhorar a sua visão, então você repara que entre as árvores há\n" 
                           + "teias enormes, ao olhar para traz percebe que o caminho por onde veio já\n" 
                           + "estava obstruído por teias.");
        System.out.println("Cenário: as árvores são mais altas que o normal, algumas árvores parecem estar\n" 
                           + "morrendo, há teias por toda a floresta, há corpos como de servos pendurados\n" 
                           + "ou até mesmo alguns javalis selvagens.");
        Game.telaDesenha(1);
        System.out.println("Narrador: A sua volta começa a ter movimento entre as árvores,ate que você ve uma aranha gigante na sua direita e outra a sua frente que pula em sua direção.");
        System.out.println("Aranhas gigantes: Aracnídeos hostis, ótimos formadores de teia.");
        Game.telaDesenha(1);
        Game.digitaAlgo();
    }
    static void apareceArcnae(){
        Game.limpaTudo();
        Game.telaDesenha(1);
        System.out.println(" Narrador: você olhou para todos os lados e reparou que só pode ir para frente, quando você está seguindo o caminho , você escuta algumas risadas de fundo, como se fizessem ekos, algum tempo depois vc repara que a risada fica mais alta, então de cima você vê algo descendo.");
        System.out.println("Uma Aracnae  metade mulher e aranha,  sua pele é branca como a neve, já sua parte aranha é tão escura que parece que ela está flutuando durante a noite.");
        
        Game.telaDesenha(1);
        Game.digitaAlgo(); 
    }
     
   static void CidadeRust() {
        Game.limpaTudo();
        Game.telaDesenha(1);
        System.out.println(" Cidade de RustLog: ");
        Game.telaDesenha(1);
        System.out.println("Narrador: você chega em uma pacata cidade, parece que muitos que estavam aqui fugiram por conta dos mortos-vivos vindos de loudwater.");
        System.out.println("Cenário: Casas com as portas arrombadas e escombros por todo lado, um verdadeiro caos.");
        Game.telaDesenha(1);
        System.out.println("Narrador: Você então se da conta da destruição que o dragão causou nos lugares que atingiu.");
        Game.digitaAlgo();
    }
   
   static void EstradaTerra() {
        Game.limpaTudo();
        Game.telaDesenha(1);
        System.out.println(" Estrada de Terra");
        Game.telaDesenha(1);
        System.out.println("Narrador: Você continua sua jornada para o reino de loudwater para matar o dragão.");
        System.out.println("Cenário : Uma estrada simples de terra que parece ser frequentada por carroças, não há nada de interessante por aqui mas certamente você está no caminho certo.");
        Game.telaDesenha(1);
        Game.digitaAlgo();
    }    
    
        static void CabanaAbandonada() {
        Game.limpaTudo();
        Game.telaDesenha(1);
        System.out.println(" Cabana Abandonada: ");
        Game.telaDesenha(1);
        System.out.println("Narrador: No fim da estrada de terra você avista um cabana abandona e decide entrar nela.");
        System.out.println("Cenário: Várias teias infestaram o lugar e você se pergunta a quanto tempo alguem não entra por ali. Um báu parece ter sido saqueado e no caldeirão uma carne que já está em processo de decomposição.");
        Game.telaDesenha(1);
        System.out.println("Narrador: Ao sair da casa você se encontra com um homem ferido.");
        System.out.println("Homem ferido: Você precisa me ajudar, meus pertences cairam no rio ali na ponte de pedra e ficaram presos em meio a alguns destroços na correnteza, tem como você me ajudar?");
        System.out.println("Narrador: Você decide ajudar o homem, já que a ponte faz parte de seu caminho.");
        Game.digitaAlgo();
    }       
     static void Ponte() {
        Game.limpaTudo();
        Game.telaDesenha(1);
        System.out.println(" Ponte de Pedra: ");
        Game.telaDesenha(1);
        System.out.println("Narrador: Você e o homem ferido chegam na ponte, você percebe que ele começa a ficar nervoso.");
        System.out.println("Cenario: Em volta do rio algumas árvores se mechem.");
        Game.telaDesenha(1);
        System.out.println("Narrador: Ao pisar na ponte o homem para de te seguir e então 1 ladrão aparece, no final da ponte, era uma armadilha!");
        Game.digitaAlgo();
    }     
     static void TavernaWineFord() {
        Game.limpaTudo();
        Game.telaDesenha(1);
        System.out.println(" Taverna WineFord: ");
        Game.telaDesenha(1);
        System.out.println("Narrador: No caminho para o Reino de LoudWater você encontra uma taverna que parece intacta mesmo perto de todo esse caos, você decide descansar para finalmente acabar sua missão.");
        Game.telaDesenha(1);
        Game.digitaAlgo();
    }     
    static void LoudWater() {
        Game.limpaTudo();
        Game.telaDesenha(1);
        System.out.println(" Reino de LoudWater: ");
        Game.telaDesenha(1);
        System.out.println("Narrador: Você chega ao Reino de LoudWater e tudo está destruído, o silêncio toma conta do lugar.");
        System.out.println("Cenário: O Portão principal está aberto e você enxerga de longe uma horda de mortos-vivos.");
        Game.telaDesenha(1);
        System.out.println("Narrador: Voce toma outro caminho para evitar a horda, ao passar por uma casa destruida, voce se depara com um minotauro(morto vivo) você terá que enfrentá-lo.");
    }   
    static void LoudWater2() {
        Game.limpaTudo();
        Game.telaDesenha(1);
        System.out.println("Narrador: Você segue rumo ao castelo, que está com buracos por todas as paredes e seu teto está despencado, diversos esqueletos estão empilhados em volta. Através dos buracos você avista o Dragão dormindo perfeitamente em baixo de um grande lustre dourado, você começa a se aproximar porém outra horda te alveja para proteger seu mestre.");
        Game.telaDesenha(1);
        System.out.println("Narrador: Então você finalmente entra no castelo, silenciosamente tenta se aproximar da besta para pegá-la de surpresa, porém um escombro do castelo acerta a cabeça da criatura e acaba acordando-a, rapidamente ela nota sua presença e abre suas asas, destruindo o que restava do andar principal do castelo e te empurrando pra longe.");
        Game.digitaAlgo();
    }     
    static void Final() {
        Game.limpaTudo();
        Game.telaDesenha(1);
        System.out.println(" Ao voltar para o Reino de Fal, toda a cidade te aplaúde e te presenteia com frutos e grãos, você finalmente se sente parte da população e deixando de ser oprimido pelos mesmos, o rei te agradece e te oferece um cargo como comandante de seus cavaleiros, aqueles que protegem o reino e a população, você aceita o cargo e agora ajudará a garantir a segurança da população, sua vida de roubos e furtos agora é passado e você não precisará mais se preocupar com isso. ");
        Game.telaDesenha(1);
        Game.digitaAlgo();
    }          
   
    
   
 }
    
    


