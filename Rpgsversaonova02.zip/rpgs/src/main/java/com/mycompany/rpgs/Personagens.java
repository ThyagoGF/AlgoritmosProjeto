package com.mycompany.rpgs;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author rodrigo
 */
public  abstract class Personagens { // usar o public abstract
    
    public String nome;
    public int maxHp,hp, xp, level;
    
    public Personagens (String nome,int maxHp,int level, int xp,int raça, int cla){
        this.hp = maxHp;
        this.maxHp = maxHp;
        this.xp = xp;
        this.nome = nome;
        this.level = level;
     
    }
    
  
}
